import os
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables from .env file
env_path = Path('.') / '.env'
load_dotenv(dotenv_path=env_path)

class Config:
    # Bot token from environment variables
    TOKEN = os.getenv('TELEGRAM_TOKEN')
    
    # Admin IDs (comma separated in .env)
    ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]
    
    # Database configuration
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///database/rpg_bot.db')
    
    # Debug mode
    DEBUG = os.getenv('DEBUG', 'False').lower() in ('true', '1', 't')
    
    # Game configuration
    STARTING_COINS = int(os.getenv('STARTING_COINS', 100))
    STARTING_ENERGY = int(os.getenv('STARTING_ENERGY', 100))
    MAX_ENERGY = int(os.getenv('MAX_ENERGY', 100))
    ENERGY_REGEN_RATE = int(os.getenv('ENERGY_REGEN_RATE', 10))  # per hour
    
    # House energy bonuses
    HOUSE_ENERGY_BONUS = {
        'tent': int(os.getenv('HOUSE_TENT_BONUS', 5)),
        'cottage': int(os.getenv('HOUSE_COTTAGE_BONUS', 15)),
        'house': int(os.getenv('HOUSE_HOUSE_BONUS', 30)),
        'manor': int(os.getenv('HOUSE_MANOR_BONUS', 50)),
        'castle': int(os.getenv('HOUSE_CASTLE_BONUS', 100))
    }
    
    # Market configuration
    MARKET_TAX_RATE = float(os.getenv('MARKET_TAX_RATE', 0.05))  # 5%
    LISTING_DURATION_HOURS = int(os.getenv('LISTING_DURATION_HOURS', 24))
    
    # Combat configuration
    BASE_HEALTH = int(os.getenv('BASE_HEALTH', 100))
    BASE_DAMAGE = int(os.getenv('BASE_DAMAGE', 10))
    
    # Path configuration
    ASSETS_PATH = os.getenv('ASSETS_PATH', 'assets')
    IMAGES_PATH = os.path.join(ASSETS_PATH, 'images')
    LOCALES_PATH = os.path.join(ASSETS_PATH, 'locales')

# Singleton config instance
config = Config()