# Item types
ITEM_TYPES = [
    'weapon',
    'armor',
    'tool',
    'material',
    'consumable',
    'resource',
    'currency',
    'quest'
]

# Rarity colors for formatting
RARITY_COLORS = {
    'common': '',
    'uncommon': '🟢',
    'rare': '🔵',
    'epic': '🟣',
    'legendary': '🟠',
    'mythic': '🔴'
}

# Job types
JOB_TYPES = [
    'labor',
    'military',
    'craft',
    'trade',
    'government',
    'criminal'
]

# Guild factions
GUILD_FACTIONS = [
    'Kingdom of Alderan',
    'Empire of Valtoria',
    'Free Cities Alliance',
    'Neutral'
]

# Crafting categories
CRAFTING_CATEGORIES = [
    'weapons',
    'armor',
    'tools',
    'consumables',
    'materials'
]

# House types
HOUSE_TYPES = [
    'tent',
    'cottage',
    'house',
    'manor',
    'castle'
]

# VIP levels
VIP_LEVELS = {
    1: {
        'name': 'Basic',
        'daily_coins': 100,
        'energy_bonus': 20,
        'shop_discount': 0,
        'color': '🟦'
    },
    2: {
        'name': 'Premium',
        'daily_coins': 250,
        'energy_bonus': 50,
        'shop_discount': 10,
        'color': '🟪'
    },
    3: {
        'name': 'Deluxe',
        'daily_coins': 500,
        'energy_bonus': 100,
        'shop_discount': 20,
        'color': '🟧'
    }
}

# Quest types
QUEST_TYPES = [
    'daily',
    'weekly',
    'story',
    'guild',
    'kingdom'
]

# Crime levels and consequences
CRIME_LEVELS = {
    0: {'title': 'Law-abiding', 'consequence': None},
    20: {'title': 'Suspicious', 'consequence': 'Higher fines'},
    50: {'title': 'Criminal', 'consequence': 'Longer sentences'},
    80: {'title': 'Outlaw', 'consequence': 'Bounty on head'}
}