import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # Game economy settings
    STARTING_COINS = int(os.getenv('STARTING_COINS', 100))
    STARTING_ENERGY = int(os.getenv('STARTING_ENERGY', 100))
    MAX_ENERGY = int(os.getenv('MAX_ENERGY', 100))
    ENERGY_REGEN_RATE = int(os.getenv('ENERGY_REGEN_RATE', 10))  # per hour
    
    # Guild settings
    GUILD_CREATION_COST = int(os.getenv('GUILD_CREATION_COST', 1000))
    GUILD_MAX_MEMBERS = int(os.getenv('GUILD_MAX_MEMBERS', 50))
    
    # Kingdom settings
    DEFAULT_TAX_RATE = float(os.getenv('DEFAULT_TAX_RATE', 0.1))  # 10%
    DEFAULT_THEFT_PENALTY = int(os.getenv('DEFAULT_THEFT_PENALTY', 50))
    DEFAULT_MURDER_PENALTY = int(os.getenv('DEFAULT_MURDER_PENALTY', 200))
    
    # Combat settings
    BASE_HEALTH = int(os.getenv('BASE_HEALTH', 100))
    BASE_DAMAGE = int(os.getenv('BASE_DAMAGE', 10))
    
    # Market settings
    MARKET_LISTING_DURATION = int(os.getenv('MARKET_LISTING_DURATION', 24))  # hours
    MARKET_FEE = float(os.getenv('MARKET_FEE', 0.05))  # 5%
    
    # Job settings
    JOB_COOLDOWN = int(os.getenv('JOB_COOLDOWN', 3600))  # 1 hour
    
    # Quest settings
    DAILY_QUEST_RESET_HOUR = int(os.getenv('DAILY_QUEST_RESET_HOUR', 0))  # midnight UTC
    WEEKLY_QUEST_RESET_DAY = int(os.getenv('WEEKLY_QUEST_RESET_DAY', 0))  # Monday
    
    # House settings
    HOUSE_ENERGY_BONUS = {
        'tent': int(os.getenv('TENT_ENERGY_BONUS', 5)),
        'cottage': int(os.getenv('COTTAGE_ENERGY_BONUS', 15)),
        'house': int(os.getenv('HOUSE_ENERGY_BONUS', 30)),
        'manor': int(os.getenv('MANOR_ENERGY_BONUS', 50)),
        'castle': int(os.getenv('CASTLE_ENERGY_BONUS', 100))
    }

settings = Settings()