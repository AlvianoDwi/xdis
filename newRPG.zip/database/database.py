from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.ext.declarative import declarative_base
from alembic.config import Config
from alembic import command
import os
from config.config import config
import logging

logger = logging.getLogger(__name__)

Base = declarative_base()

def init_db():
    """Initialize database connection and create tables"""
    engine = create_engine(config.DATABASE_URL)
    
    if config.DATABASE_URL.startswith('sqlite'):
        # Enable foreign key support for SQLite
        def _fk_pragma_on_connect(dbapi_con, con_record):
            dbapi_con.execute('PRAGMA foreign_keys=ON')
        
        from sqlalchemy import event
        event.listen(engine, 'connect', _fk_pragma_on_connect)

    Session = scoped_session(sessionmaker(bind=engine))
    Base.metadata.bind = engine
    
    # Create tables if they don't exist
    try:
        Base.metadata.create_all(engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")
        raise
    
    # Run migrations
    run_migrations()
    
    return Session

def run_migrations():
    """Run database migrations using Alembic"""
    try:
        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", config.DATABASE_URL)
        command.upgrade(alembic_cfg, "head")
        logger.info("Database migrations applied successfully")
    except Exception as e:
        logger.error(f"Error running database migrations: {e}")
        raise

def get_session():
    """Get a new database session"""
    engine = create_engine(config.DATABASE_URL)
    Session = sessionmaker(bind=engine)
    return Session()