from datetime import datetime, timedelta
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, JSON, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False)
    username = Column(String(50))
    first_name = Column(String(50))
    last_name = Column(String(50))
    title = Column(String(50), default="Peasant")
    coins = Column(Integer, default=100)
    bank = Column(Integer, default=0)
    exp = Column(Integer, default=0)
    level = Column(Integer, default=1)
    energy = Column(Integer, default=100)
    max_energy = Column(Integer, default=100)
    health = Column(Integer, default=100)
    max_health = Column(Integer, default=100)
    stamina = Column(Integer, default=50)
    strength = Column(Integer, default=10)
    agility = Column(Integer, default=10)
    intelligence = Column(Integer, default=10)
    charisma = Column(Integer, default=10)
    reputation = Column(Integer, default=0)
    crime_level = Column(Integer, default=0)
    vip_level = Column(Integer, default=0)
    vip_expire = Column(DateTime)
    guild_id = Column(Integer, ForeignKey('guilds.id'))
    job_id = Column(Integer, ForeignKey('jobs.id'))
    house_id = Column(Integer, ForeignKey('houses.id'))
    jailed = Column(Boolean, default=False)
    jail_time = Column(DateTime)
    jail_reason = Column(Text)
    last_active = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_energy_refill = Column(DateTime, default=datetime.utcnow)
    last_daily_reward = Column(DateTime)
    last_weekly_reward = Column(DateTime)
    
    inventory = relationship("InventoryItem", back_populates="user")
    guild = relationship("Guild", back_populates="members")
    job = relationship("Job")
    house = relationship("House")
    transactions = relationship("Transaction", back_populates="user")
    listings = relationship("MarketListing", back_populates="seller")
    quests = relationship("PlayerQuest", back_populates="player")
    achievements = relationship("PlayerAchievement", back_populates="player")

class InventoryItem(Base):
    __tablename__ = 'inventory'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    item_id = Column(String(50))
    quantity = Column(Integer, default=1)
    durability = Column(Integer)
    max_durability = Column(Integer)
    equipped = Column(Boolean, default=False)
    
    user = relationship("User", back_populates="inventory")

class Item(Base):
    __tablename__ = 'items'
    
    id = Column(String(50), primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    type = Column(String(20))  # weapon, armor, tool, material, consumable
    subtype = Column(String(20))  # sword, axe, herb, etc.
    rarity = Column(String(20))  # common, uncommon, rare, epic, legendary
    value = Column(Integer)
    stats = Column(JSON)  # { "attack": 5, "defense": 3 }
    durability = Column(Integer)
    required_level = Column(Integer, default=1)
    vip_only = Column(Boolean, default=False)
    craftable = Column(Boolean, default=False)
    tradable = Column(Boolean, default=True)
    consumable = Column(Boolean, default=False)
    effect = Column(JSON)  # { "health_restore": 20, "energy_restore": 10 }

class Guild(Base):
    __tablename__ = 'guilds'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True)
    description = Column(Text)
    level = Column(Integer, default=1)
    treasury = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    leader_id = Column(Integer, ForeignKey('users.id'))
    faction = Column(String(20))  # kingdom allegiance
    
    members = relationship("User", back_populates="guild")
    leader = relationship("User", foreign_keys=[leader_id])

class Job(Base):
    __tablename__ = 'jobs'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    base_salary = Column(Integer)
    salary_increase = Column(Integer, default=5)  # per level
    required_level = Column(Integer, default=1)
    energy_cost = Column(Integer, default=10)
    cooldown = Column(Integer, default=3600)  # in seconds
    type = Column(String(20))  # labor, military, craft, etc.

class House(Base):
    __tablename__ = 'houses'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    price = Column(Integer)
    capacity = Column(Integer)  # inventory slots
    energy_bonus = Column(Integer)
    level_requirement = Column(Integer, default=1)
    image = Column(String(100))  # path to image

class Transaction(Base):
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Integer)
    type = Column(String(20))  # buy, sell, trade, salary, etc.
    item_id = Column(String(50))
    quantity = Column(Integer)
    timestamp = Column(DateTime, default=datetime.utcnow)
    details = Column(JSON)  # additional info
    
    user = relationship("User", back_populates="transactions")

class MarketListing(Base):
    __tablename__ = 'market_listings'
    
    id = Column(Integer, primary_key=True)
    seller_id = Column(Integer, ForeignKey('users.id'))
    item_id = Column(String(50))
    quantity = Column(Integer)
    price = Column(Integer)
    listing_type = Column(String(10))  # p2p, npc
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    
    seller = relationship("User", back_populates="listings")

class Quest(Base):
    __tablename__ = 'quests'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    type = Column(String(10))  # daily, weekly, story
    reward_coins = Column(Integer)
    reward_exp = Column(Integer)
    reward_items = Column(JSON)  # [{"item_id": "sword", "quantity": 1}]
    requirements = Column(JSON)  # {"level": 5, "items": [{"item_id": "herb", "quantity": 3}]}
    energy_cost = Column(Integer, default=10)
    cooldown = Column(Integer)  # in seconds
    repeatable = Column(Boolean, default=False)
    faction_requirement = Column(String(20))

class PlayerQuest(Base):
    __tablename__ = 'player_quests'
    
    id = Column(Integer, primary_key=True)
    player_id = Column(Integer, ForeignKey('users.id'))
    quest_id = Column(Integer, ForeignKey('quests.id'))
    progress = Column(JSON)  # {"items_collected": 1, "monsters_killed": 0}
    completed = Column(Boolean, default=False)
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    player = relationship("User", back_populates="quests")
    quest = relationship("Quest")

class Achievement(Base):
    __tablename__ = 'achievements'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    reward_coins = Column(Integer)
    reward_exp = Column(Integer)
    reward_item = Column(String(50))
    condition = Column(JSON)  # {"stat": "level", "value": 10} or {"action": "craft", "count": 50}

class PlayerAchievement(Base):
    __tablename__ = 'player_achievements'
    
    id = Column(Integer, primary_key=True)
    player_id = Column(Integer, ForeignKey('users.id'))
    achievement_id = Column(Integer, ForeignKey('achievements.id'))
    completed_at = Column(DateTime, default=datetime.utcnow)
    
    player = relationship("User", back_populates="achievements")
    achievement = relationship("Achievement")

class Kingdom(Base):
    __tablename__ = 'kingdoms'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    treasury = Column(Integer, default=10000)
    tax_rate = Column(Float, default=0.1)  # 10%
    laws = Column(JSON)  # {"theft_penalty": 50, "murder_penalty": 100}
    leader_id = Column(Integer, ForeignKey('users.id'))
    
    leader = relationship("User")

class PrisonJob(Base):
    __tablename__ = 'prison_jobs'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    reward = Column(Integer)  # coins per hour
    energy_cost = Column(Integer, default=20)
    crime_reduction = Column(Integer)  # how much it reduces crime level

class RobberyRecord(Base):
    __tablename__ = 'robbery_records'
    
    id = Column(Integer, primary_key=True)
    robber_id = Column(Integer, ForeignKey('users.id'))
    victim_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Integer)
    success = Column(Boolean)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    robber = relationship("User", foreign_keys=[robber_id])
    victim = relationship("User", foreign_keys=[victim_id])

class CraftingRecipe(Base):
    __tablename__ = 'crafting_recipes'
    
    id = Column(Integer, primary_key=True)
    item_id = Column(String(50), ForeignKey('items.id'))
    materials = Column(JSON)  # {"wood": 5, "iron": 2}
    skill_requirement = Column(String(20))
    skill_level = Column(Integer, default=1)
    energy_cost = Column(Integer, default=10)
    
    item = relationship("Item")

class MedicineRecipe(Base):
    __tablename__ = 'medicine_recipes'
    
    id = Column(Integer, primary_key=True)
    item_id = Column(String(50), ForeignKey('items.id'))
    materials = Column(JSON)
    effect = Column(JSON)
    duration = Column(Integer)  # in minutes
    
    item = relationship("Item")

class VIPPackage(Base):
    __tablename__ = 'vip_packages'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    duration = Column(Integer)  # in days
    price = Column(Integer)
    benefits = Column(JSON)  # {"daily_coins": 100, "energy_bonus": 20}

class Event(Base):
    __tablename__ = 'events'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    description = Column(Text)
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    modifiers = Column(JSON)  # {"exp_gain": 1.5, "drop_rate": 2.0}
    special_items = Column(JSON)  # ["event_sword", "event_potion"]