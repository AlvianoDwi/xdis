import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler
from handlers import (
    admin, combat, crafting, economy, farming, guilds, housing,
    jobs, kingdom, main, market, p2p, player, prison, quests, vip
)
from config import config
from utils.logger import setup_logger
from database.database import init_db

# Setup logging
setup_logger()
logger = logging.getLogger(__name__)

def main():
    """Start the bot."""
    # Initialize database
    init_db()
    
    # Create the Updater and pass it your bot's token
    updater = Updater(config.TOKEN, use_context=True)
    
    # Get the dispatcher to register handlers
    dp = updater.dispatcher
    
    # Register handlers from all modules
    main.register_handlers(dp)
    admin.register_handlers(dp)
    player.register_handlers(dp)
    economy.register_handlers(dp)
    p2p.register_handlers(dp)
    market.register_handlers(dp)
    crafting.register_handlers(dp)
    farming.register_handlers(dp)
    jobs.register_handlers(dp)
    guilds.register_handlers(dp)
    kingdom.register_handlers(dp)
    prison.register_handlers(dp)
    quests.register_handlers(dp)
    vip.register_handlers(dp)
    housing.register_handlers(dp)
    combat.register_handlers(dp)
    
    # Start the Bot
    updater.start_polling()
    logger.info("Bot started and running...")
    updater.idle()

if __name__ == '__main__':
    main()