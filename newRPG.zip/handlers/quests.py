from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, Quest, PlayerQuest, InventoryItem
from utils.helpers import format_coins, progress_bar
from utils.decorators import log_command
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@log_command
def quests(update, context):
    """Show available quests"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Get available quests
    available_quests = session.query(Quest).filter(
        Quest.required_level <= user.level
    ).order_by(Quest.reward_coins.desc()).all()
    
    # Get player's active quests
    active_quests = session.query(PlayerQuest).filter(
        PlayerQuest.player_id == user.id,
        PlayerQuest.completed == False
    ).all()
    
    # Get player's completed quests
    completed_quests = session.query(PlayerQuest).filter(
        PlayerQuest.player_id == user.id,
        PlayerQuest.completed == True
    ).order_by(PlayerQuest.completed_at.desc()).limit(5).all()
    
    message = "📜 *Quest Board* 📜\n\n"
    
    if active_quests:
        message += "🔵 *Active Quests:*\n"
        for pq in active_quests:
            progress = ""
            if pq.progress:
                for k, v in pq.progress.items():
                    progress += f"{k}: {v}\n"
            
            message += (
                f"• *{pq.quest.name}* - {pq.quest.description}\n"
                f"{progress}\n"
            )
    
    message += "\n🟢 *Available Quests:*\n"
    for quest in available_quests:
        # Check if player already has this quest active
        if any(pq.quest_id == quest.id for pq in active_quests):
            continue
        
        message += (
            f"• *{quest.name}* - {quest.description}\n"
            f"💰 Reward: {format_coins(quest.reward_coins)} + {quest.reward_exp} EXP\n"
            f"⚡ Energy cost: {quest.energy_cost}\n\n"
        )
    
    if completed_quests:
        message += "\n🟣 *Recently Completed:*\n"
        for pq in completed_quests:
            message += f"• {pq.quest.name} - Completed {pq.completed_at.strftime('%Y-%m-%d')}\n"
    
    keyboard = []
    for quest in available_quests:
        # Only show available quests not already active
        if not any(pq.quest_id == quest.id for pq in active_quests):
            keyboard.append(
                [InlineKeyboardButton(f"Accept {quest.name}", callback_data=f'quest_accept_{quest.id}')]
            )
    
    for pq in active_quests:
        keyboard.append(
            [InlineKeyboardButton(f"Check {pq.quest.name}", callback_data=f'quest_check_{pq.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Daily Quests", callback_data='quests_daily')])
    keyboard.append([InlineKeyboardButton("Weekly Quests", callback_data='quests_weekly')])
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def accept_quest(update, context):
    """Accept a new quest"""
    query = update.callback_query
    query.answer()
    
    quest_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    quest = session.query(Quest).get(quest_id)
    
    if not user or not quest:
        query.edit_message_text("User or quest not found!")
        session.close()
        return
    
    # Check if already has this quest
    existing = session.query(PlayerQuest).filter(
        PlayerQuest.player_id == user.id,
        PlayerQuest.quest_id == quest.id,
        PlayerQuest.completed == False
    ).first()
    
    if existing:
        query.edit_message_text("You already have this quest active!")
        session.close()
        return
    
    # Check max active quests (3)
    active_count = session.query(PlayerQuest).filter(
        PlayerQuest.player_id == user.id,
        PlayerQuest.completed == False
    ).count()
    
    if active_count >= 3:
        query.edit_message_text("You can only have 3 active quests at a time!")
        session.close()
        return
    
    # Create player quest
    player_quest = PlayerQuest(
        player_id=user.id,
        quest_id=quest.id,
        progress={}  # Initialize empty progress
    )
    session.add(player_quest)
    session.commit()
    
    query.edit_message_text(
        f"🎉 Quest accepted: *{quest.name}*\n\n"
        f"{quest.description}\n\n"
        "Check your quest progress with /quests",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def check_quest(update, context):
    """Check quest progress"""
    query = update.callback_query
    query.answer()
    
    player_quest_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    player_quest = session.query(PlayerQuest).get(player_quest_id)
    
    if not player_quest or player_quest.player.telegram_id != user_id:
        query.edit_message_text("Quest not found!")
        session.close()
        return
    
    quest = player_quest.quest
    
    # Format progress
    progress_text = ""
    if player_quest.progress:
        for k, v in player_quest.progress.items():
            progress_text += f"• {k}: {v}\n"
    else:
        progress_text = "No progress yet\n"
    
    # Check if quest is complete
    complete = True
    if quest.requirements:
        for req, value in quest.requirements.items():
            if req == 'level':
                if user.level < value:
                    complete = False
            elif req == 'items':
                for item_req in value:
                    item_id = item_req['item_id']
                    quantity = item_req['quantity']
                    
                    inventory_item = session.query(InventoryItem).filter(
                        InventoryItem.user_id == player_quest.player_id,
                        InventoryItem.item_id == item_id,
                        InventoryItem.quantity >= quantity
                    ).first()
                    
                    if not inventory_item:
                        complete = False
    
    if complete:
        # Complete quest
        player_quest.completed = True
        player_quest.completed_at = datetime.utcnow()
        
        # Give rewards
        player = player_quest.player
        player.coins += quest.reward_coins
        player.exp += quest.reward_exp
        
        # Give item rewards
        if quest.reward_items:
            for item_reward in quest.reward_items:
                item_id = item_reward['item_id']
                quantity = item_reward['quantity']
                
                existing = session.query(InventoryItem).filter(
                    InventoryItem.user_id == player.id,
                    InventoryItem.item_id == item_id
                ).first()
                
                if existing:
                    existing.quantity += quantity
                else:
                    new_item = InventoryItem(
                        user_id=player.id,
                        item_id=item_id,
                        quantity=quantity
                    )
                    session.add(new_item)
        
        session.commit()
        
        query.edit_message_text(
            f"🎉 Quest completed: *{quest.name}* 🎉\n\n"
            f"💰 Received: {format_coins(quest.reward_coins)}\n"
            f"⭐ EXP Gained: {quest.reward_exp}\n"
            f"{'🎁 And other rewards!' if quest.reward_items else ''}",
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        query.edit_message_text(
            f"📜 *{quest.name}* 📜\n\n"
            f"{quest.description}\n\n"
            f"*Progress:*\n{progress_text}\n"
            f"💰 Reward: {format_coins(quest.reward_coins)} + {quest.reward_exp} EXP",
            parse_mode=ParseMode.MARKDOWN
        )
    
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("quests", quests))
    dp.add_handler(CallbackQueryHandler(accept_quest, pattern='^quest_accept_'))
    dp.add_handler(CallbackQueryHandler(check_quest, pattern='^quest_check_'))