from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CallbackQueryHandler, CommandHandler
from database.database import Session
from database.models import Item, User, Inventory
from config.config import recipes
from utils.helpers import format_coins
import logging

logger = logging.getLogger(__name__)

def crafting_menu(update, context):
    """Show crafting menu"""
    keyboard = [
        [InlineKeyboardButton("Weapons", callback_data='craft_weapons')],
        [InlineKeyboardButton("Armor", callback_data='craft_armor')],
        [InlineKeyboardButton("Tools", callback_data='craft_tools')],
        [InlineKeyboardButton("Consumables", callback_data='craft_consumables')],
    ]
    
    update.message.reply_text(
        "⚒️ *Crafting Workshop* ⚒️\n\n"
        "Choose what you want to craft:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def show_crafting_category(update, context):
    """Show items in a crafting category"""
    query = update.callback_query
    query.answer()
    
    category = query.data.split('_')[1]
    session = Session()
    craftable_items = session.query(Item).filter(
        Item.type == category,
        Item.id.in_(recipes.keys())
    ).all()
    
    if not craftable_items:
        query.edit_message_text("No craftable items in this category yet!")
        return
    
    keyboard = []
    for item in craftable_items:
        keyboard.append(
            [InlineKeyboardButton(item.name, callback_data=f'craft_item_{item.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='craft_back')])
    
    query.edit_message_text(
        f"⚒️ *Crafting {category.capitalize()}* ⚒️\n\n"
        "Select an item to see requirements:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def show_crafting_recipe(update, context):
    """Show recipe for a specific item"""
    query = update.callback_query
    query.answer()
    
    item_id = query.data.split('_')[2]
    session = Session()
    item = session.query(Item).get(item_id)
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    if not item or not user:
        query.edit_message_text("Item or user not found!")
        session.close()
        return
    
    recipe = recipes.get(item_id, {})
    requirements = recipe.get('materials', {})
    energy_cost = recipe.get('energy', 10)
    
    # Check if user has materials
    has_materials = True
    materials_text = ""
    for mat_id, quantity in requirements.items():
        mat_item = session.query(Item).get(mat_id)
        inv_item = next((i for i in user.inventory if i.item_id == mat_id), None)
        has_enough = inv_item.quantity >= quantity if inv_item else False
        has_materials = has_materials and has_enough
        
        materials_text += (
            f"{'✅' if has_enough else '❌'} {mat_item.name} x{quantity}\n"
        )
    
    keyboard = []
    if has_materials and user.energy >= energy_cost:
        keyboard.append(
            [InlineKeyboardButton("Craft Item", callback_data=f'craft_execute_{item_id}')]
        )
    keyboard.append([InlineKeyboardButton("Back", callback_data=f'craft_{item.type}s')])
    
    query.edit_message_text(
        f"⚒️ *Crafting {item.name}* ⚒️\n\n"
        f"📜 *Description:* {item.description}\n"
        f"⭐ *Rarity:* {item.rarity.capitalize()}\n"
        f"💎 *Value:* {format_coins(item.value)}\n\n"
        f"🔧 *Requirements:*\n{materials_text}\n"
        f"⚡ *Energy Cost:* {energy_cost}\n\n"
        f"{'You have all required materials!' if has_materials else 'You are missing some materials!'}",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def execute_crafting(update, context):
    """Execute the crafting process"""
    query = update.callback_query
    query.answer()
    
    item_id = query.data.split('_')[2]
    session = Session()
    item = session.query(Item).get(item_id)
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    if not item or not user:
        query.edit_message_text("Item or user not found!")
        session.close()
        return
    
    recipe = recipes.get(item_id, {})
    requirements = recipe.get('materials', {})
    energy_cost = recipe.get('energy', 10)
    
    # Verify again in case of race condition
    has_materials = True
    for mat_id, quantity in requirements.items():
        inv_item = next((i for i in user.inventory if i.item_id == mat_id), None)
        if not inv_item or inv_item.quantity < quantity:
            has_materials = False
            break
    
    if not has_materials or user.energy < energy_cost:
        query.edit_message_text(
            "You don't have enough materials or energy to craft this item!"
        )
        session.close()
        return
    
    # Deduct materials
    for mat_id, quantity in requirements.items():
        inv_item = next(i for i in user.inventory if i.item_id == mat_id)
        inv_item.quantity -= quantity
        if inv_item.quantity <= 0:
            session.delete(inv_item)
    
    # Deduct energy
    user.energy -= energy_cost
    
    # Add crafted item
    existing_item = next((i for i in user.inventory if i.item_id == item_id), None)
    if existing_item:
        existing_item.quantity += 1
    else:
        new_item = Inventory(
            user_id=user.id,
            item_id=item_id,
            quantity=1,
            durability=item.durability,
            max_durability=item.durability
        )
        session.add(new_item)
    
    session.commit()
    
    query.edit_message_text(
        f"⚒️ *Crafting Successful!* ⚒️\n\n"
        f"You have crafted a {item.name}!\n\n"
        f"⚡ Energy used: {energy_cost}\n"
        f"🛠️ Durability: {item.durability}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("craft", crafting_menu))
    dp.add_handler(CallbackQueryHandler(show_crafting_category, pattern='^craft_(weapons|armor|tools|consumables)$'))
    dp.add_handler(CallbackQueryHandler(show_crafting_recipe, pattern='^craft_item_'))
    dp.add_handler(CallbackQueryHandler(execute_crafting, pattern='^craft_execute_'))
    dp.add_handler(CallbackQueryHandler(crafting_menu, pattern='^craft_back$'))