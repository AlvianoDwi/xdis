# Import semua handler yang diperlukan
from .admin import register_handlers as admin_handlers
from .combat import register_handlers as combat_handlers
from .crafting import register_handlers as crafting_handlers
from .economy import register_handlers as economy_handlers
from .events import register_handlers as events_handlers
from .farming import register_handlers as farming_handlers
from .guilds import register_handlers as guild_handlers
from .housing import register_handlers as housing_handlers
from .jobs import register_handlers as jobs_handlers
from .kingdom import register_handlers as kingdom_handlers
from .market import register_handlers as market_handlers
from .p2p import register_handlers as p2p_handlers
from .player import register_handlers as player_handlers
from .prison import register_handlers as prison_handlers
from .quests import register_handlers as quests_handlers
from .robbery import register_handlers as robbery_handlers
from .shops import register_handlers as shops_handlers
from .skills import register_handlers as skills_handlers
from .tavern import register_handlers as tavern_handlers
from .vip import register_handlers as vip_handlers

def register_all_handlers(dp):
    admin_handlers(dp)
    combat_handlers(dp)
    crafting_handlers(dp)
    economy_handlers(dp)
    events_handlers(dp)
    farming_handlers(dp)
    guild_handlers(dp)
    housing_handlers(dp)
    jobs_handlers(dp)
    kingdom_handlers(dp)
    market_handlers(dp)
    p2p_handlers(dp)
    player_handlers(dp)
    prison_handlers(dp)
    quests_handlers(dp)
    robbery_handlers(dp)
    shops_handlers(dp)
    skills_handlers(dp)
    tavern_handlers(dp)
    vip_handlers(dp)