from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler, ConversationHandler
from database.database import Session
from database.models import MarketListing, User, Item
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

# Market states
BROWSING, VIEWING_ITEM, PURCHASING = range(3)

@log_command
def market(update, context):
    """Show the main market interface"""
    session = Session()
    
    # Get NPC listings (items sold by the system)
    npc_listings = session.query(MarketListing).filter(
        MarketListing.listing_type == 'npc'
    ).order_by(MarketListing.item.has(Item.type)).limit(10).all()
    
    # Get categories for filtering
    categories = session.query(Item.type).distinct().all()
    
    message = "🏪 *Marketplace* 🏪\n\n"
    message += "Browse goods from merchants and traders:\n"
    
    keyboard = [
        [InlineKeyboardButton("Weapons", callback_data='market_category_weapon')],
        [InlineKeyboardButton("Armor", callback_data='market_category_armor')],
        [InlineKeyboardButton("Tools", callback_data='market_category_tool')],
        [InlineKeyboardButton("Consumables", callback_data='market_category_consumable')],
        [InlineKeyboardButton("My Listings", callback_data='market_mylistings')]
    ]
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return BROWSING

def show_category(update, context):
    """Show items in a specific category"""
    query = update.callback_query
    query.answer()
    
    category = query.data.split('_')[2]
    session = Session()
    
    items = session.query(MarketListing).join(Item).filter(
        MarketListing.listing_type == 'npc',
        Item.type == category
    ).limit(10).all()
    
    if not items:
        query.edit_message_text(f"No items available in the {category} category.")
        session.close()
        return BROWSING
    
    message = f"🏪 *{category.capitalize()} Market* 🏪\n\n"
    
    for item in items:
        message += (
            f"• *{item.item.name}* - {format_coins(item.price)}\n"
            f"  {item.item.description}\n"
            f"  Stock: {item.quantity}\n\n"
        )
    
    keyboard = []
    for item in items:
        keyboard.append(
            [InlineKeyboardButton(item.item.name, callback_data=f'market_item_{item.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='market_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return VIEWING_ITEM

def show_item(update, context):
    """Show details for a specific market item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    session = Session()
    listing = session.query(MarketListing).get(item_id)
    
    if not listing:
        query.edit_message_text("Item not found!")
        session.close()
        return ConversationHandler.END
    
    item = listing.item
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    message = (
        f"🛒 *{item.name}* 🛒\n\n"
        f"📜 *Description:* {item.description}\n"
        f"💰 *Price:* {format_coins(listing.price)}\n"
        f"📦 *Available:* {listing.quantity}\n\n"
    )
    
    if item.stats:
        message += "*Attributes:*\n"
        for stat, value in item.stats.items():
            message += f"• {stat.replace('_', ' ').title()}: {value}\n"
        message += "\n"
    
    keyboard = []
    
    if user.coins >= listing.price:
        keyboard.append(
            [InlineKeyboardButton("Purchase", callback_data=f'market_purchase_{listing.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='market_category_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return PURCHASING

def purchase_item(update, context):
    """Handle item purchase"""
    query = update.callback_query
    query.answer()
    
    listing_id = int(query.data.split('_')[2])
    session = Session()
    
    listing = session.query(MarketListing).get(listing_id)
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    if not listing or not user:
        query.edit_message_text("Item or user not found!")
        session.close()
        return ConversationHandler.END
    
    if listing.quantity <= 0:
        query.edit_message_text("This item is out of stock!")
        session.close()
        return ConversationHandler.END
    
    if user.coins < listing.price:
        query.edit_message_text(
            f"You don't have enough coins to buy this!\n"
            f"Price: {format_coins(listing.price)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return PURCHASING
    
    # Process purchase
    user.coins -= listing.price
    listing.quantity -= 1
    
    # Add item to user's inventory
    existing_item = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.item_id == listing.item_id
    ).first()
    
    if existing_item:
        existing_item.quantity += 1
    else:
        new_item = InventoryItem(
            user_id=user.id,
            item_id=listing.item_id,
            quantity=1,
            durability=listing.item.durability,
            max_durability=listing.item.durability
        )
        session.add(new_item)
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=listing.price,
        type="market_purchase",
        item_id=listing.item_id,
        quantity=1,
        details={"listing_type": "npc"}
    )
    session.add(transaction)
    
    session.commit()
    
    query.edit_message_text(
        f"🎉 You purchased {listing.item.name} for {format_coins(listing.price)}!\n"
        f"New balance: {format_coins(user.coins)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return ConversationHandler.END

def market_back(update, context):
    """Return to main market menu"""
    query = update.callback_query
    query.answer()
    market(update, context)
    return ConversationHandler.END

def category_back(update, context):
    """Return to category view"""
    query = update.callback_query
    query.answer()
    show_category(update, context)
    return VIEWING_ITEM

def cancel_market(update, context):
    """Cancel market interaction"""
    update.message.reply_text("Market interaction cancelled.")
    return ConversationHandler.END

def register_handlers(dp):
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("market", market)],
        states={
            BROWSING: [
                CallbackQueryHandler(show_category, pattern='^market_category_'),
                CallbackQueryHandler(market_back, pattern='^market_back$'),
            ],
            VIEWING_ITEM: [
                CallbackQueryHandler(show_item, pattern='^market_item_'),
                CallbackQueryHandler(market_back, pattern='^market_back$'),
                CallbackQueryHandler(category_back, pattern='^market_category_back$'),
            ],
            PURCHASING: [
                CallbackQueryHandler(purchase_item, pattern='^market_purchase_'),
                CallbackQueryHandler(show_item, pattern='^market_item_'),
                CallbackQueryHandler(market_back, pattern='^market_back$'),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel_market)],
    )
    
    dp.add_handler(conv_handler)