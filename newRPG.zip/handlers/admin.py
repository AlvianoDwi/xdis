from telegram import ParseMode
from telegram.ext import CommandHandler
from database.database import Session
from database.models import User, Item
from utils.decorators import restricted, log_command
from utils.helpers import format_coins
import logging

logger = logging.getLogger(__name__)

@restricted
@log_command
def give_item(update, context):
    """Give item to a player (admin only)"""
    if len(context.args) < 3:
        update.message.reply_text(
            "Usage: /giveitem <user_id> <item_id> <quantity> [durability]"
        )
        return
    
    user_id = context.args[0]
    item_id = context.args[1]
    quantity = int(context.args[2])
    durability = int(context.args[3]) if len(context.args) > 3 else None
    
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    item = session.query(Item).filter(Item.id == item_id).first()
    
    if not user or not item:
        update.message.reply_text("User or item not found!")
        session.close()
        return
    
    # Add item to inventory
    inventory_item = next(
        (i for i in user.inventory if i.item_id == item_id and 
         (i.durability == durability if durability else True)),
        None
    )
    
    if inventory_item:
        inventory_item.quantity += quantity
    else:
        new_item = Inventory(
            user_id=user.id,
            item_id=item_id,
            quantity=quantity,
            durability=durability if durability else item.durability,
            max_durability=durability if durability else item.durability
        )
        session.add(new_item)
    
    session.commit()
    session.close()
    
    update.message.reply_text(
        f"Given {quantity}x {item.name} to user {user.username or user.first_name}!"
    )

@restricted
@log_command
def give_coins(update, context):
    """Give coins to a player (admin only)"""
    if len(context.args) < 2:
        update.message.reply_text("Usage: /givecoins <user_id> <amount>")
        return
    
    user_id = context.args[0]
    amount = int(context.args[1])
    
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    user.coins += amount
    session.commit()
    session.close()
    
    update.message.reply_text(
        f"Given {format_coins(amount)} to user {user.username or user.first_name}!"
    )

@restricted
@log_command
def jail_user(update, context):
    """Jail a player (admin only)"""
    if len(context.args) < 1:
        update.message.reply_text("Usage: /jail <user_id> [hours] [reason]")
        return
    
    user_id = context.args[0]
    hours = int(context.args[1]) if len(context.args) > 1 else 24
    reason = " ".join(context.args[2:]) if len(context.args) > 2 else "Unspecified"
    
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    user.jailed = True
    user.jail_time = datetime.utcnow() + timedelta(hours=hours)
    session.commit()
    session.close()
    
    update.message.reply_text(
        f"User {user.username or user.first_name} has been jailed for {hours} hours.\n"
        f"Reason: {reason}"
    )

def register_handlers(dp):
    dp.add_handler(CommandHandler("giveitem", give_item))
    dp.add_handler(CommandHandler("givecoins", give_coins))
    dp.add_handler(CommandHandler("giveexp", give_exp))
    dp.add_handler(CommandHandler("jail", jail_user))
    dp.add_handler(CommandHandler("unjail", unjail_user))
    dp.add_handler(CommandHandler("heal", heal_player))
    # ... other admin commands