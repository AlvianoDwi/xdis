from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler, ConversationHandler
from database.database import Session
from database.models import User, InventoryItem, Achievement, PlayerAchievement
from utils.helpers import format_coins, progress_bar
from utils.decorators import log_command
from config.constants import ITEM_TYPES, RARITY_COLORS
import logging
import math

logger = logging.getLogger(__name__)

@log_command
def profile(update, context):
    """Show player profile"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Calculate level progress
    current_level_exp = 100 * (user.level ** 2)
    next_level_exp = 100 * ((user.level + 1) ** 2)
    exp_progress = (user.exp - current_level_exp) / (next_level_exp - current_level_exp) * 100
    
    # Get equipped items
    equipped_items = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.equipped == True
    ).all()
    
    # Format equipped items
    equipment_text = ""
    for item in equipped_items:
        durability_text = ""
        if item.durability is not None:
            durability_text = f" ({item.durability}/{item.max_durability})"
        equipment_text += f"• {item.item_id}{durability_text}\n"
    
    # Get achievements count
    achievements_count = session.query(PlayerAchievement).filter(
        PlayerAchievement.player_id == user.id
    ).count()
    
    # VIP status
    vip_status = "None"
    if user.vip_level > 0:
        vip_status = f"Level {user.vip_level}"
        if user.vip_expire:
            vip_status += f" (Expires: {user.vip_expire.strftime('%Y-%m-%d')})"
    
    # Create profile text
    profile_text = (
        f"🏰 *{user.title} {user.first_name}* 🏰\n\n"
        f"⚔️ Level: {user.level} ({progress_bar(exp_progress)} {user.exp}/{next_level_exp} EXP)\n"
        f"💰 Coins: {format_coins(user.coins)} | Bank: {format_coins(user.bank)}\n"
        f"❤️ Health: {user.health}/{user.max_health}\n"
        f"⚡ Energy: {user.energy}/{user.max_energy}\n"
        f"🏆 Reputation: {user.reputation}\n"
        f"👑 VIP: {vip_status}\n"
        f"🏆 Achievements: {achievements_count}\n\n"
        f"📊 *Stats:*\n"
        f"💪 Strength: {user.strength}\n"
        f"🏃‍♂️ Agility: {user.agility}\n"
        f"🧠 Intelligence: {user.intelligence}\n"
        f"🎭 Charisma: {user.charisma}\n\n"
        f"🛡️ *Equipment:*\n{equipment_text if equipment_text else 'None'}\n"
    )
    
    # Add guild info if in a guild
    if user.guild:
        profile_text += f"🏛️ Guild: {user.guild.name} (Level {user.guild.level})\n"
    
    # Add job info if employed
    if user.job:
        profile_text += f"💼 Job: {user.job.name}\n"
    
    # Add house info if has house
    if user.house:
        profile_text += f"🏠 House: {user.house.name}\n"
    
    # Create keyboard
    keyboard = [
        [InlineKeyboardButton("Inventory", callback_data='player_inventory')],
        [InlineKeyboardButton("Skills", callback_data='player_skills')],
        [InlineKeyboardButton("Achievements", callback_data='player_achievements')],
        [InlineKeyboardButton("Quests", callback_data='player_quests')],
    ]
    
    update.message.reply_text(
        profile_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def show_inventory(update, context):
    """Show player inventory"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    inventory_items = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id
    ).order_by(InventoryItem.item_id).all()
    
    if not inventory_items:
        query.edit_message_text("Your inventory is empty!")
        session.close()
        return
    
    # Group items by type
    items_by_type = {}
    for item in inventory_items:
        item_type = item.item.type if hasattr(item, 'item') else 'unknown'
        if item_type not in items_by_type:
            items_by_type[item_type] = []
        items_by_type[item_type].append(item)
    
    # Create inventory text
    inventory_text = "🎒 *Inventory* 🎒\n\n"
    for item_type in ITEM_TYPES:
        if item_type in items_by_type:
            inventory_text += f"*{item_type.capitalize()}s:*\n"
            for item in items_by_type[item_type]:
                durability_text = ""
                if item.durability is not None:
                    durability_text = f" ({item.durability}/{item.max_durability})"
                equipped_text = " [EQUIPPED]" if item.equipped else ""
                inventory_text += f"• {item.item_id} x{item.quantity}{durability_text}{equipped_text}\n"
            inventory_text += "\n"
    
    # Create keyboard with item type filters
    keyboard = []
    row = []
    for item_type in ITEM_TYPES:
        row.append(InlineKeyboardButton(item_type.capitalize(), callback_data=f'inv_filter_{item_type}'))
        if len(row) == 3:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Back to Profile", callback_data='player_profile')])
    
    query.edit_message_text(
        inventory_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def filter_inventory(update, context):
    """Filter inventory by item type"""
    query = update.callback_query
    query.answer()
    
    item_type = query.data.split('_')[2]
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Get items of specified type
    inventory_items = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.item.has(type=item_type)
    ).all()
    
    if not inventory_items:
        query.edit_message_text(f"You have no {item_type} items!")
        session.close()
        return
    
    # Create filtered inventory text
    inventory_text = f"🎒 *{item_type.capitalize()} Inventory* 🎒\n\n"
    for item in inventory_items:
        durability_text = ""
        if item.durability is not None:
            durability_text = f" ({item.durability}/{item.max_durability})"
        equipped_text = " [EQUIPPED]" if item.equipped else ""
        inventory_text += f"• {item.item_id} x{item.quantity}{durability_text}{equipped_text}\n"
    
    # Create action buttons for each item
    keyboard = []
    for item in inventory_items:
        keyboard.append([
            InlineKeyboardButton(
                f"{item.item_id} x{item.quantity}",
                callback_data=f'inv_item_{item.id}'
            )
        ])
    
    keyboard.append([InlineKeyboardButton("Back to Inventory", callback_data='player_inventory')])
    
    query.edit_message_text(
        inventory_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def show_item_details(update, context):
    """Show details for a specific inventory item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    item = inventory_item.item
    rarity_color = RARITY_COLORS.get(item.rarity, "")
    
    # Format item stats
    stats_text = ""
    if item.stats:
        for stat, value in item.stats.items():
            stats_text += f"• {stat.replace('_', ' ').title()}: {value}\n"
    
    # Format item effects
    effects_text = ""
    if item.effect:
        for effect, value in item.effect.items():
            effects_text += f"• {effect.replace('_', ' ').title()}: {value}\n"
    
    # Create item details text
    item_text = (
        f"{rarity_color}*{item.name}*{rarity_color}\n\n"
        f"📜 *Description:* {item.description}\n"
        f"⭐ *Rarity:* {item.rarity.capitalize()}\n"
        f"💎 *Value:* {format_coins(item.value)}\n"
        f"📦 *Type:* {item.type.capitalize()}\n"
        f"🛠️ *Durability:* "
        f"{inventory_item.durability}/{inventory_item.max_durability}\n\n"
    )
    
    if stats_text:
        item_text += f"📊 *Stats:*\n{stats_text}\n"
    
    if effects_text:
        item_text += f"✨ *Effects:*\n{effects_text}\n"
    
    # Create action buttons
    keyboard = []
    
    # Equip/Unequip for equipment
    if item.type in ['weapon', 'armor']:
        if inventory_item.equipped:
            keyboard.append([
                InlineKeyboardButton("Unequip", callback_data=f'inv_unequip_{item_id}')
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("Equip", callback_data=f'inv_equip_{item_id}')
            ])
    
    # Use for consumables
    if item.consumable:
        keyboard.append([
            InlineKeyboardButton("Use", callback_data=f'inv_use_{item_id}')
        ])
    
    # Sell for tradable items
    if item.tradable:
        keyboard.append([
            InlineKeyboardButton("Sell", callback_data=f'inv_sell_{item_id}')
        ])
    
    # Repair for items with durability
    if item.durability and inventory_item.durability < inventory_item.max_durability:
        repair_cost = math.ceil((inventory_item.max_durability - inventory_item.durability) * item.value * 0.1)
        keyboard.append([
            InlineKeyboardButton(f"Repair ({format_coins(repair_cost)})", callback_data=f'inv_repair_{item_id}')
        ])
    
    keyboard.append([
        InlineKeyboardButton("Back", callback_data=f'inv_filter_{item.type}')
    ])
    
    query.edit_message_text(
        item_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def equip_item(update, context):
    """Equip an item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if inventory_item.equipped:
        query.edit_message_text("Item is already equipped!")
        session.close()
        return
    
    # Check if item is equipment
    if inventory_item.item.type not in ['weapon', 'armor']:
        query.edit_message_text("This item cannot be equipped!")
        session.close()
        return
    
    # Unequip any items of the same type
    same_type_items = session.query(InventoryItem).filter(
        InventoryItem.user_id == inventory_item.user_id,
        InventoryItem.equipped == True,
        InventoryItem.item.has(type=inventory_item.item.type)
    ).all()
    
    for item in same_type_items:
        item.equipped = False
    
    # Equip the new item
    inventory_item.equipped = True
    session.commit()
    
    query.edit_message_text(f"You have equipped {inventory_item.item_id}!")
    session.close()

def unequip_item(update, context):
    """Unequip an item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if not inventory_item.equipped:
        query.edit_message_text("Item is not equipped!")
        session.close()
        return
    
    inventory_item.equipped = False
    session.commit()
    
    query.edit_message_text(f"You have unequipped {inventory_item.item_id}!")
    session.close()

def use_item(update, context):
    """Use a consumable item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if not inventory_item.item.consumable:
        query.edit_message_text("This item cannot be used!")
        session.close()
        return
    
    user = inventory_item.user
    item = inventory_item.item
    
    # Apply effects
    message = f"You used {item.name}!\n\n"
    if item.effect:
        for effect, value in item.effect.items():
            if effect == 'health_restore':
                user.health = min(user.max_health, user.health + value)
                message += f"❤️ Restored {value} health!\n"
            elif effect == 'energy_restore':
                user.energy = min(user.max_energy, user.energy + value)
                message += f"⚡ Restored {value} energy!\n"
            elif effect == 'stamina_boost':
                user.stamina += value
                message += f"🏃‍♂️ Gained {value} stamina!\n"
    
    # Remove the item
    inventory_item.quantity -= 1
    if inventory_item.quantity <= 0:
        session.delete(inventory_item)
    
    session.commit()
    
    query.edit_message_text(message)
    session.close()

def sell_item(update, context):
    """Initiate selling an item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if not inventory_item.item.tradable:
        query.edit_message_text("This item cannot be sold!")
        session.close()
        return
    
    # Calculate base price (with durability consideration)
    base_price = inventory_item.item.value
    if inventory_item.durability is not None:
        durability_ratio = inventory_item.durability / inventory_item.max_durability
        base_price = int(base_price * durability_ratio)
    
    # Create keyboard with quantity options
    max_quantity = min(inventory_item.quantity, 10)  # Limit to 10 for UI
    keyboard = []
    row = []
    for qty in range(1, max_quantity + 1):
        row.append(InlineKeyboardButton(str(qty), callback_data=f'inv_sellqty_{item_id}_{qty}'))
        if len(row) == 3:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Cancel", callback_data=f'inv_item_{item_id}')])
    
    query.edit_message_text(
        f"Sell {inventory_item.item_id} for {format_coins(base_price)} each?\n"
        "Select quantity:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def confirm_sell_item(update, context):
    """Confirm selling an item"""
    query = update.callback_query
    query.answer()
    
    _, item_id, quantity = query.data.split('_')
    item_id = int(item_id)
    quantity = int(quantity)
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if inventory_item.quantity < quantity:
        query.edit_message_text("You don't have enough of this item!")
        session.close()
        return
    
    # Calculate final price
    base_price = inventory_item.item.value
    if inventory_item.durability is not None:
        durability_ratio = inventory_item.durability / inventory_item.max_durability
        base_price = int(base_price * durability_ratio)
    
    total_price = base_price * quantity
    
    # Create transaction
    transaction = Transaction(
        user_id=inventory_item.user_id,
        amount=total_price,
        type="sell",
        item_id=inventory_item.item_id,
        quantity=quantity
    )
    session.add(transaction)
    
    # Update user coins
    user = inventory_item.user
    user.coins += total_price
    
    # Remove items
    inventory_item.quantity -= quantity
    if inventory_item.quantity <= 0:
        session.delete(inventory_item)
    
    session.commit()
    
    query.edit_message_text(
        f"You sold {quantity}x {inventory_item.item_id} for {format_coins(total_price)}!"
    )
    session.close()

def repair_item(update, context):
    """Repair an item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    
    inventory_item = session.query(InventoryItem).get(item_id)
    if not inventory_item or inventory_item.user.telegram_id != user_id:
        query.edit_message_text("Item not found!")
        session.close()
        return
    
    if inventory_item.durability is None:
        query.edit_message_text("This item doesn't need repair!")
        session.close()
        return
    
    if inventory_item.durability >= inventory_item.max_durability:
        query.edit_message_text("This item is already at full durability!")
        session.close()
        return
    
    # Calculate repair cost
    repair_cost = math.ceil(
        (inventory_item.max_durability - inventory_item.durability) * 
        inventory_item.item.value * 0.1
    )
    
    user = inventory_item.user
    if user.coins < repair_cost:
        query.edit_message_text(
            f"You need {format_coins(repair_cost)} to repair this item!"
        )
        session.close()
        return
    
    # Perform repair
    user.coins -= repair_cost
    inventory_item.durability = inventory_item.max_durability
    session.commit()
    
    query.edit_message_text(
        f"You repaired {inventory_item.item_id} for {format_coins(repair_cost)}!\n"
        f"Durability restored to {inventory_item.durability}/{inventory_item.max_durability}."
    )
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("profile", profile))
    
    # Inventory callbacks
    dp.add_handler(CallbackQueryHandler(show_inventory, pattern='^player_inventory$'))
    dp.add_handler(CallbackQueryHandler(filter_inventory, pattern='^inv_filter_'))
    dp.add_handler(CallbackQueryHandler(show_item_details, pattern='^inv_item_'))
    dp.add_handler(CallbackQueryHandler(equip_item, pattern='^inv_equip_'))
    dp.add_handler(CallbackQueryHandler(unequip_item, pattern='^inv_unequip_'))
    dp.add_handler(CallbackQueryHandler(use_item, pattern='^inv_use_'))
    dp.add_handler(CallbackQueryHandler(sell_item, pattern='^inv_sell_'))
    dp.add_handler(CallbackQueryHandler(confirm_sell_item, pattern='^inv_sellqty_'))
    dp.add_handler(CallbackQueryHandler(repair_item, pattern='^inv_repair_'))
    
    # Profile navigation
    dp.add_handler(CallbackQueryHandler(profile, pattern='^player_profile$'))