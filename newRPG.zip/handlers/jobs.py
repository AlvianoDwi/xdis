from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, Job, Transaction
from utils.helpers import format_coins, progress_bar
from utils.decorators import log_command, cooldown
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@log_command
def jobs(update, context):
    """Show available jobs"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Get available jobs based on player level
    available_jobs = session.query(Job).filter(
        Job.required_level <= user.level
    ).order_by(Job.base_salary.desc()).all()
    
    if not available_jobs:
        update.message.reply_text("No jobs available for your level yet!")
        session.close()
        return
    
    # Check current job
    current_job = None
    if user.job:
        current_job = f"Current job: {user.job.name} (Salary: {format_coins(user.job.base_salary)})"
    
    message = "💼 *Available Jobs* 💼\n\n"
    if current_job:
        message += f"{current_job}\n\n"
    
    message += "Choose a job to work:\n"
    for job in available_jobs:
        message += (
            f"• *{job.name}* - {format_coins(job.base_salary)}\n"
            f"  ⚡ Energy cost: {job.energy_cost}\n"
            f"  📜 {job.description}\n\n"
        )
    
    keyboard = []
    for job in available_jobs:
        keyboard.append(
            [InlineKeyboardButton(f"Work as {job.name}", callback_data=f'job_work_{job.id}')]
        )
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

@cooldown(minutes=30)
def work_job(update, context):
    """Perform job work"""
    query = update.callback_query
    query.answer()
    
    job_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    job = session.query(Job).get(job_id)
    
    if not user or not job:
        query.edit_message_text("User or job not found!")
        session.close()
        return
    
    # Check energy
    if user.energy < job.energy_cost:
        query.edit_message_text(
            f"You need {job.energy_cost} energy to work as {job.name}!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= job.energy_cost
    
    # Calculate salary (with potential bonuses)
    salary = job.base_salary
    if user.job and user.job.id == job.id:
        # Loyalty bonus for staying with same job
        salary += job.base_salary // 5
    
    # Add charisma bonus
    salary += user.charisma * 2
    
    # Add coins
    user.coins += salary
    
    # Add exp
    exp_gain = job.base_salary // 10
    user.exp += exp_gain
    
    # Set/update current job
    user.job_id = job.id
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=salary,
        type="job_salary",
        details={"job_id": job.id, "job_name": job.name}
    )
    session.add(transaction)
    session.commit()
    
    # Format result message
    message = (
        f"💼 *Work Results* 💼\n\n"
        f"You worked as {job.name} and earned {format_coins(salary)}!\n"
        f"⚔️ Gained {exp_gain} EXP\n\n"
        f"Current energy: {user.energy}/{user.max_energy}"
    )
    
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("jobs", jobs))
    dp.add_handler(CallbackQueryHandler(work_job, pattern='^job_work_'))