from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler, ConversationHandler
from database.database import Session
from database.models import User, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command
import logging
import math

logger = logging.getLogger(__name__)

# Conversation states for banking
BANK_ACTION, BANK_DEPOSIT, BANK_WITHDRAW = range(3)

@log_command
def economy(update, context):
    """Show economy commands"""
    keyboard = [
        [InlineKeyboardButton("Bank", callback_data='economy_bank')],
        [InlineKeyboardButton("Market", callback_data='economy_market')],
        [InlineKeyboardButton("Jobs", callback_data='economy_jobs')],
        [InlineKeyboardButton("Trade", callback_data='economy_trade')],
    ]
    
    update.message.reply_text(
        "💰 *Economy Menu* 💰\n\n"
        "Manage your finances and trade with others:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def bank_menu(update, context):
    """Show bank menu"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Deposit", callback_data='bank_deposit')],
        [InlineKeyboardButton("Withdraw", callback_data='bank_withdraw')],
        [InlineKeyboardButton("Back", callback_data='economy_back')],
    ]
    
    query.edit_message_text(
        f"🏦 *Royal Bank* 🏦\n\n"
        f"💰 Coins: {format_coins(user.coins)}\n"
        f"🏦 Bank: {format_coins(user.bank)}\n\n"
        "What would you like to do?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return BANK_ACTION

def bank_deposit(update, context):
    """Initiate deposit"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Create deposit amount options
    amounts = [
        math.ceil(user.coins * 0.25),
        math.ceil(user.coins * 0.5),
        math.ceil(user.coins * 0.75),
        user.coins
    ]
    amounts = sorted(list(set(amounts)))  # Remove duplicates
    
    keyboard = []
    row = []
    for amount in amounts:
        if amount > 0:
            row.append(InlineKeyboardButton(
                format_coins(amount),
                callback_data=f'bank_deposit_{amount}'
            ))
            if len(row) == 2:
                keyboard.append(row)
                row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='bank_deposit_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='bank_back')])
    
    query.edit_message_text(
        "How much would you like to deposit?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()
    return BANK_DEPOSIT

def process_deposit(update, context):
    """Process deposit transaction"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'bank_deposit_custom':
        query.edit_message_text(
            "Please enter the amount you want to deposit:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='bank_back')]
            ])
        )
        return BANK_DEPOSIT
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return BANK_ACTION
    
    if amount <= 0:
        query.edit_message_text("Amount must be positive!")
        session.close()
        return BANK_ACTION
    
    if user.coins < amount:
        query.edit_message_text("You don't have enough coins!")
        session.close()
        return BANK_ACTION
    
    # Process deposit
    user.coins -= amount
    user.bank += amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=amount,
        type="deposit",
        details={"location": "bank"}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"💰 You deposited {format_coins(amount)} into your bank account!\n\n"
        f"New balance: {format_coins(user.bank)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return BANK_ACTION

def bank_withdraw(update, context):
    """Initiate withdraw"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Create withdraw amount options
    amounts = [
        math.ceil(user.bank * 0.25),
        math.ceil(user.bank * 0.5),
        math.ceil(user.bank * 0.75),
        user.bank
    ]
    amounts = sorted(list(set(amounts)))  # Remove duplicates
    
    keyboard = []
    row = []
    for amount in amounts:
        if amount > 0:
            row.append(InlineKeyboardButton(
                format_coins(amount),
                callback_data=f'bank_withdraw_{amount}'
            ))
            if len(row) == 2:
                keyboard.append(row)
                row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='bank_withdraw_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='bank_back')])
    
    query.edit_message_text(
        "How much would you like to withdraw?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()
    return BANK_WITHDRAW

def process_withdraw(update, context):
    """Process withdraw transaction"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'bank_withdraw_custom':
        query.edit_message_text(
            "Please enter the amount you want to withdraw:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='bank_back')]
            ])
        )
        return BANK_WITHDRAW
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return BANK_ACTION
    
    if amount <= 0:
        query.edit_message_text("Amount must be positive!")
        session.close()
        return BANK_ACTION
    
    if user.bank < amount:
        query.edit_message_text("You don't have enough coins in your bank!")
        session.close()
        return BANK_ACTION
    
    # Process withdraw
    user.coins += amount
    user.bank -= amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=amount,
        type="withdraw",
        details={"location": "bank"}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"💰 You withdrew {format_coins(amount)} from your bank account!\n\n"
        f"New balance: {format_coins(user.bank)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return BANK_ACTION

def process_custom_amount(update, context):
    """Process custom deposit/withdraw amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount <= 0:
            update.message.reply_text("Amount must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user:
            update.message.reply_text("User not found!")
            session.close()
            return
        
        # Determine if this is for deposit or withdraw
        if context.user_data.get('bank_action') == 'deposit':
            if user.coins < amount:
                update.message.reply_text("You don't have enough coins!")
                session.close()
                return
            
            user.coins -= amount
            user.bank += amount
            action = "deposited"
            
            # Record transaction
            transaction = Transaction(
                user_id=user.id,
                amount=amount,
                type="deposit",
                details={"location": "bank", "custom": True}
            )
        else:  # withdraw
            if user.bank < amount:
                update.message.reply_text("You don't have enough coins in your bank!")
                session.close()
                return
            
            user.coins += amount
            user.bank -= amount
            action = "withdrawn"
            
            # Record transaction
            transaction = Transaction(
                user_id=user.id,
                amount=amount,
                type="withdraw",
                details={"location": "bank", "custom": True}
            )
        
        session.add(transaction)
        session.commit()
        
        update.message.reply_text(
            f"💰 You {action} {format_coins(amount)}!\n\n"
            f"New balances:\n"
            f"Coins: {format_coins(user.coins)}\n"
            f"Bank: {format_coins(user.bank)}",
            parse_mode=ParseMode.MARKDOWN
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")
    
    return BANK_ACTION

def bank_back(update, context):
    """Go back to bank menu"""
    query = update.callback_query
    query.answer()
    return bank_menu(update, context)

def economy_back(update, context):
    """Go back to economy menu"""
    query = update.callback_query
    query.answer()
    economy(update, context)
    return ConversationHandler.END

def cancel_banking(update, context):
    """Cancel banking operation"""
    update.message.reply_text("Banking operation cancelled.")
    return ConversationHandler.END

def register_handlers(dp):
    dp.add_handler(CommandHandler("economy", economy))
    
    # Banking conversation handler
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(bank_menu, pattern='^economy_bank$')],
        states={
            BANK_ACTION: [
                CallbackQueryHandler(bank_deposit, pattern='^bank_deposit$'),
                CallbackQueryHandler(bank_withdraw, pattern='^bank_withdraw$'),
                CallbackQueryHandler(economy_back, pattern='^economy_back$'),
            ],
            BANK_DEPOSIT: [
                CallbackQueryHandler(process_deposit, pattern='^bank_deposit_'),
                CallbackQueryHandler(bank_back, pattern='^bank_back$'),
                MessageHandler(Filters.text & ~Filters.command, process_custom_amount),
            ],
            BANK_WITHDRAW: [
                CallbackQueryHandler(process_withdraw, pattern='^bank_withdraw_'),
                CallbackQueryHandler(bank_back, pattern='^bank_back$'),
                MessageHandler(Filters.text & ~Filters.command, process_custom_amount),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel_banking)],
    )
    
    dp.add_handler(conv_handler)
    dp.add_handler(CallbackQueryHandler(economy, pattern='^economy_back$'))