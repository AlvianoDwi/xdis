from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, InventoryItem
from utils.helpers import format_coins, progress_bar
from utils.decorators import log_command, requires_tool
import logging
import random

logger = logging.getLogger(__name__)

@log_command
def combat(update, context):
    """Show combat options"""
    keyboard = [
        [InlineKeyboardButton("Duel Player", callback_data='combat_duel')],
        [InlineKeyboardButton("Hunt Animals", callback_data='combat_hunt')],
        [InlineKeyboardButton("Arena", callback_data='combat_arena')],
        [InlineKeyboardButton("Equipment", callback_data='combat_equipment')],
    ]
    
    update.message.reply_text(
        "⚔️ *Combat Menu* ⚔️\n\n"
        "Choose your combat activity:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def duel_player(update, context):
    """Initiate duel with another player"""
    query = update.callback_query
    query.answer()
    
    if len(context.args) < 1:
        query.edit_message_text("Usage: /duel <user_id>")
        return
    
    try:
        target_id = int(context.args[0])
    except ValueError:
        query.edit_message_text("Invalid user ID! Usage: /duel <user_id>")
        return
    
    attacker_id = query.from_user.id
    if attacker_id == target_id:
        query.edit_message_text("You can't duel yourself!")
        return
    
    session = Session()
    attacker = session.query(User).filter(User.telegram_id == attacker_id).first()
    target = session.query(User).filter(User.telegram_id == target_id).first()
    
    if not attacker or not target:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    if attacker.jailed or target.jailed:
        query.edit_message_text("You can't duel someone who's in prison!")
        session.close()
        return
    
    # Check if both players have weapons equipped
    attacker_weapon = session.query(InventoryItem).filter(
        InventoryItem.user_id == attacker.id,
        InventoryItem.equipped == True,
        InventoryItem.item.has(type='weapon')
    ).first()
    
    target_weapon = session.query(InventoryItem).filter(
        InventoryItem.user_id == target.id,
        InventoryItem.equipped == True,
        InventoryItem.item.has(type='weapon')
    ).first()
    
    if not attacker_weapon or not target_weapon:
        query.edit_message_text("Both players need to have a weapon equipped to duel!")
        session.close()
        return
    
    # Calculate duel outcome
    attacker_power = attacker.strength + (attacker_weapon.item.stats['attack'] if attacker_weapon.item.stats else 0)
    target_power = target.strength + (target_weapon.item.stats['attack'] if target_weapon.item.stats else 0)
    
    # Add some randomness
    attacker_roll = random.uniform(0.8, 1.2)
    target_roll = random.uniform(0.8, 1.2)
    
    attacker_score = attacker_power * attacker_roll
    target_score = target_power * target_roll
    
    # Determine winner
    if attacker_score > target_score:
        winner = attacker
        loser = target
        winner_score = attacker_score
        loser_score = target_score
    else:
        winner = target
        loser = attacker
        winner_score = target_score
        loser_score = attacker_score
    
    # Calculate damage (10-30% of loser's health)
    damage_percent = random.uniform(0.1, 0.3)
    damage = int(loser.health * damage_percent)
    loser.health = max(1, loser.health - damage)
    
    # Calculate exp gain based on difficulty
    exp_gain = int(loser_score * 0.5)
    winner.exp += exp_gain
    
    # Reduce weapon durability
    if attacker_weapon.durability is not None:
        attacker_weapon.durability -= 1
        if attacker_weapon.durability <= 0:
            session.delete(attacker_weapon)
    
    if target_weapon.durability is not None:
        target_weapon.durability -= 1
        if target_weapon.durability <= 0:
            session.delete(target_weapon)
    
    # Record duel results
    session.commit()
    
    # Format result message
    message = (
        f"⚔️ *Duel Results* ⚔️\n\n"
        f"🏆 Winner: {winner.username or winner.first_name} (Score: {int(winner_score)})\n"
        f"💔 Loser: {loser.username or loser.first_name} (Score: {int(loser_score)})\n\n"
        f"❤️ {loser.username or loser.first_name} lost {damage} health (now {loser.health}/{loser.max_health})\n"
        f"⭐ {winner.username or winner.first_name} gained {exp_gain} EXP\n"
    )
    
    if attacker_weapon.durability == 0 or target_weapon.durability == 0:
        message += "\n⚠️ A weapon broke during the duel!"
    
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

@requires_tool('weapon')
def hunt_animals(update, context):
    """Hunt animals for resources"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Check energy
    energy_cost = 20
    if user.energy < energy_cost:
        query.edit_message_text(
            f"You need {energy_cost} energy to go hunting!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= energy_cost
    
    # Get equipped weapon
    weapon = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.equipped == True,
        InventoryItem.item.has(type='weapon')
    ).first()
    
    if not weapon:
        query.edit_message_text("You need a weapon equipped to hunt!")
        session.close()
        return
    
    # Possible hunting rewards
    rewards = [
        {'id': 'meat', 'name': 'Meat', 'min': 1, 'max': 5, 'chance': 0.8},
        {'id': 'hide', 'name': 'Animal Hide', 'min': 1, 'max': 3, 'chance': 0.6},
        {'id': 'bone', 'name': 'Bone', 'min': 1, 'max': 4, 'chance': 0.7},
        {'id': 'rare_pelt', 'name': 'Rare Pelt', 'min': 1, 'max': 1, 'chance': 0.2}
    ]
    
    # Calculate success based on weapon quality and player stats
    weapon_quality = weapon.item.stats.get('quality', 1) if weapon.item.stats else 1
    success_modifier = 1 + (user.agility * 0.01) + (weapon_quality * 0.1)
    
    gathered = []
    for reward in rewards:
        effective_chance = reward['chance'] * success_modifier
        if random.random() < effective_chance:
            amount = random.randint(reward['min'], reward['max'])
            gathered.append({'id': reward['id'], 'name': reward['name'], 'amount': amount})
            
            # Add to inventory
            existing = session.query(InventoryItem).filter(
                InventoryItem.user_id == user.id,
                InventoryItem.item_id == reward['id']
            ).first()
            
            if existing:
                existing.quantity += amount
            else:
                new_item = InventoryItem(
                    user_id=user.id,
                    item_id=reward['id'],
                    quantity=amount
                )
                session.add(new_item)
    
    # Calculate exp gain
    exp_gain = len(gathered) * 10
    user.exp += exp_gain
    
    # Reduce weapon durability
    if weapon.durability is not None:
        weapon.durability -= 1
        if weapon.durability <= 0:
            session.delete(weapon)
            weapon_broke = True
        else:
            weapon_broke = False
    
    # Format result message
    message = "🏹 *Hunting Results* 🏹\n\n"
    if gathered:
        message += "You gathered:\n"
        for item in gathered:
            message += f"• {item['name']} x{item['amount']}\n"
        
        message += f"\n⚔️ Gained {exp_gain} EXP\n"
    else:
        message += "Your hunt was unsuccessful this time.\n"
    
    if weapon_broke:
        message += "\n⚠️ Your weapon broke from use!"
    
    session.commit()
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("combat", combat))
    dp.add_handler(CommandHandler("duel", duel_player))
    dp.add_handler(CallbackQueryHandler(duel_player, pattern='^combat_duel$'))
    dp.add_handler(CallbackQueryHandler(hunt_animals, pattern='^combat_hunt$'))