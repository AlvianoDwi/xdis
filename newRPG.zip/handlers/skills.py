from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, Skill
from utils.helpers import progress_bar
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

@log_command
def skills(update, context):
    """Show player skills and progression"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    skills = session.query(Skill).filter(Skill.user_id == user.id).all()
    
    message = "📚 *Skills* 📚\n\n"
    message += "Your character's abilities and proficiencies:\n\n"
    
    for skill in skills:
        exp_needed = 100 * (skill.level ** 2)
        progress = (skill.experience / exp_needed) * 100
        message += (
            f"• *{skill.name}* (Lv. {skill.level})\n"
            f"  {progress_bar(progress)} {skill.experience}/{exp_needed} XP\n"
            f"  {skill.description}\n\n"
        )
    
    keyboard = [
        [InlineKeyboardButton("Skill Training", callback_data='skills_training')],
        [InlineKeyboardButton("Skill Bonuses", callback_data='skills_bonuses')]
    ]
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def skill_training(update, context):
    """Show skill training options"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    skills = session.query(Skill).filter(Skill.user_id == user.id).all()
    
    message = "🏋️ *Skill Training* 🏋️\n\n"
    message += "Improve your skills through practice:\n\n"
    
    keyboard = []
    for skill in skills:
        keyboard.append(
            [InlineKeyboardButton(
                f"Train {skill.name} (Cost: {skill.energy_cost} energy)",
                callback_data=f'skill_train_{skill.id}'
            )]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='skills_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def train_skill(update, context):
    """Train a specific skill"""
    query = update.callback_query
    query.answer()
    
    skill_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    skill = session.query(Skill).get(skill_id)
    
    if not user or not skill or skill.user_id != user.id:
        query.edit_message_text("Skill or user not found!")
        session.close()
        return
    
    if user.energy < skill.energy_cost:
        query.edit_message_text(
            f"You need {skill.energy_cost} energy to train {skill.name}!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= skill.energy_cost
    
    # Gain skill experience
    exp_gain = 10 + (user.intelligence * 0.5)
    skill.experience += exp_gain
    
    # Check for level up
    exp_needed = 100 * (skill.level ** 2)
    if skill.experience >= exp_needed:
        skill.level += 1
        skill.experience = 0
        level_up = True
    else:
        level_up = False
    
    session.commit()
    
    message = (
        f"🏋️ You trained {skill.name} and gained {exp_gain:.1f} XP!\n"
        f"Current level: {skill.level}\n"
        f"Progress: {progress_bar((skill.experience/exp_needed)*100)}\n"
    )
    
    if level_up:
        message += f"\n🎉 *Level Up!* Your {skill.name} is now level {skill.level}!"
    
    query.edit_message_text(
        message,
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def skill_bonuses(update, context):
    """Show skill bonuses and effects"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    skills = session.query(Skill).filter(Skill.user_id == user.id).all()
    
    message = "✨ *Skill Bonuses* ✨\n\n"
    message += "Your skills provide the following benefits:\n\n"
    
    for skill in skills:
        message += f"• *{skill.name}* (Lv. {skill.level})\n"
        for effect, value in skill.effects.items():
            if isinstance(value, dict):
                # Handle scaling bonuses
                base = value['base']
                per_level = value['per_level']
                total = base + (per_level * skill.level)
                message += f"  - {effect.replace('_', ' ').title()}: +{total}\n"
            else:
                message += f"  - {effect.replace('_', ' ').title()}: {value}\n"
        message += "\n"
    
    keyboard = [
        [InlineKeyboardButton("Back", callback_data='skills_back')]
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def skills_back(update, context):
    """Return to skills overview"""
    query = update.callback_query
    query.answer()
    skills(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("skills", skills))
    dp.add_handler(CallbackQueryHandler(skill_training, pattern='^skills_training$'))
    dp.add_handler(CallbackQueryHandler(train_skill, pattern='^skill_train_'))
    dp.add_handler(CallbackQueryHandler(skill_bonuses, pattern='^skills_bonuses$'))
    dp.add_handler(CallbackQueryHandler(skills_back, pattern='^skills_back$'))