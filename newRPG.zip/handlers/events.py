from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import Event, User
from utils.helpers import format_coins
from utils.decorators import log_command
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@log_command
def events(update, context):
    """Show current events"""
    session = Session()
    current_time = datetime.utcnow()
    active_events = session.query(Event).filter(
        Event.start_time <= current_time,
        Event.end_time >= current_time
    ).all()
    
    if not active_events:
        update.message.reply_text(
            "There are no active events at the moment. Check back later!",
            parse_mode=ParseMode.MARKDOWN
        )
        session.close()
        return
    
    message = "🎉 *Active Events* 🎉\n\n"
    for event in active_events:
        time_left = event.end_time - current_time
        days = time_left.days
        hours = int(time_left.seconds // 3600)
        
        message += (
            f"✨ *{event.name}*\n"
            f"📜 {event.description}\n"
            f"⏳ Ends in: {days}d {hours}h\n\n"
            "Event bonuses:\n"
        )
        
        for modifier, value in event.modifiers.items():
            message += f"• {modifier.replace('_', ' ').title()}: {value}x\n"
        
        message += "\n"
    
    keyboard = [
        [InlineKeyboardButton("Event Shop", callback_data='event_shop')],
        [InlineKeyboardButton("Event Quests", callback_data='event_quests')]
    ]
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def event_shop(update, context):
    """Show event-specific shop items"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    current_time = datetime.utcnow()
    active_events = session.query(Event).filter(
        Event.start_time <= current_time,
        Event.end_time >= current_time
    ).all()
    
    if not active_events:
        query.edit_message_text("No active events with shops available.")
        session.close()
        return
    
    # Get event items
    event_items = []
    for event in active_events:
        if event.special_items:
            event_items.extend(event.special_items)
    
    if not event_items:
        query.edit_message_text("No special items available in event shops.")
        session.close()
        return
    
    message = "🎁 *Event Shop* 🎁\n\n"
    message += "Special limited-time items:\n\n"
    
    # Get item details from database
    items = session.query(Item).filter(Item.id.in_(event_items)).all()
    
    for item in items:
        message += (
            f"• *{item.name}* - {format_coins(item.value)}\n"
            f"  {item.description}\n\n"
        )
    
    keyboard = []
    for item in items:
        keyboard.append(
            [InlineKeyboardButton(f"Buy {item.name}", callback_data=f'event_buy_{item.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='events_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def event_quests(update, context):
    """Show event-specific quests"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    current_time = datetime.utcnow()
    active_events = session.query(Event).filter(
        Event.start_time <= current_time,
        Event.end_time >= current_time
    ).all()
    
    if not active_events:
        query.edit_message_text("No active events with quests available.")
        session.close()
        return
    
    message = "🏆 *Event Quests* 🏆\n\n"
    
    for event in active_events:
        message += f"✨ *{event.name}* ✨\n"
        
        # In a real implementation, you'd have event quests in your database
        # For now we'll use placeholder quests
        message += (
            "• *Festival Participation*\n"
            "  Participate in 3 festival activities\n"
            "  Reward: 100 coins, 50 XP\n\n"
            
            "• *Collect Event Tokens*\n"
            "  Gather 10 event tokens\n"
            "  Reward: 200 coins, Special Item\n\n"
        )
    
    keyboard = [
        [InlineKeyboardButton("Back", callback_data='events_back')]
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def events_back(update, context):
    """Go back to main events menu"""
    query = update.callback_query
    query.answer()
    events(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("events", events))
    dp.add_handler(CallbackQueryHandler(event_shop, pattern='^event_shop$'))
    dp.add_handler(CallbackQueryHandler(event_quests, pattern='^event_quests$'))
    dp.add_handler(CallbackQueryHandler(events_back, pattern='^events_back$'))