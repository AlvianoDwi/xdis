from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, InventoryItem
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

@log_command
def tavern(update, context):
    """Show tavern menu"""
    keyboard = [
        [InlineKeyboardButton("Buy Drink", callback_data='tavern_drinks')],
        [InlineKeyboardButton("Play Dice Game", callback_data='tavern_dice')],
        [InlineKeyboardButton("Hear Rumors", callback_data='tavern_rumors')],
    ]
    
    update.message.reply_text(
        "🍻 *Tavern* 🍻\n\n"
        "Welcome to the local tavern! What would you like to do?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def show_drinks(update, context):
    """Show available drinks"""
    query = update.callback_query
    query.answer()
    
    drinks = [
        {"id": "ale", "name": "Ale", "price": 10, "energy": 5, "effect": "Restores 5 energy"},
        {"id": "wine", "name": "Wine", "price": 25, "energy": 10, "effect": "Restores 10 energy"},
        {"id": "mead", "name": "Mead", "price": 50, "energy": 20, "effect": "Restores 20 energy"},
    ]
    
    keyboard = []
    for drink in drinks:
        keyboard.append([
            InlineKeyboardButton(
                f"{drink['name']} - {format_coins(drink['price'])}",
                callback_data=f'tavern_buy_{drink["id"]}'
            )
        ])
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='tavern_back')])
    
    query.edit_message_text(
        "🍺 *Available Drinks* 🍺\n\n" +
        "\n".join([
            f"• *{d['name']}* - {format_coins(d['price'])}\n"
            f"  {d['effect']}\n" 
            for d in drinks
        ]),
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def buy_drink(update, context):
    """Process drink purchase"""
    query = update.callback_query
    query.answer()
    
    drink_id = query.data.split('_')[2]
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Get drink info
    drinks = {
        "ale": {"name": "Ale", "price": 10, "energy": 5},
        "wine": {"name": "Wine", "price": 25, "energy": 10},
        "mead": {"name": "Mead", "price": 50, "energy": 20},
    }
    
    drink = drinks.get(drink_id)
    if not drink:
        query.edit_message_text("Drink not found!")
        session.close()
        return
    
    if user.coins < drink['price']:
        query.edit_message_text(
            f"You don't have enough coins for {drink['name']}!\n"
            f"Required: {format_coins(drink['price'])}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Process purchase
    user.coins -= drink['price']
    user.energy = min(user.max_energy, user.energy + drink['energy'])
    
    session.commit()
    
    query.edit_message_text(
        f"🍺 You drank {drink['name']} and restored {drink['energy']} energy!\n"
        f"Current energy: {user.energy}/{user.max_energy}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def play_dice(update, context):
    """Play dice game"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    bet = 10  # Fixed bet amount
    
    if user.coins < bet:
        query.edit_message_text(
            f"You need {format_coins(bet)} to play the dice game!\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Roll dice
    player_roll = random.randint(1, 6)
    tavern_roll = random.randint(1, 6)
    
    if player_roll > tavern_roll:
        # Player wins
        winnings = bet * 2
        user.coins += winnings
        result = f"You won {format_coins(winnings)}!"
    elif player_roll < tavern_roll:
        # Player loses
        user.coins -= bet
        result = f"You lost {format_coins(bet)}."
    else:
        # Tie
        result = "It's a tie! Your bet is returned."
    
    session.commit()
    
    query.edit_message_text(
        f"🎲 *Dice Game* 🎲\n\n"
        f"Your roll: {player_roll}\n"
        f"Tavern roll: {tavern_roll}\n\n"
        f"{result}\n\n"
        f"Your coins: {format_coins(user.coins)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def hear_rumors(update, context):
    """Share random rumors"""
    query = update.callback_query
    query.answer()
    
    rumors = [
        "They say the king is planning a grand tournament next month...",
        "I heard there's a dragon sighted in the northern mountains!",
        "A merchant caravan was robbed on the eastern road yesterday...",
        "The blacksmith got a shipment of rare metals from the dwarves.",
        "There's talk of a new guild forming in the city.",
        "Someone found a hidden dungeon beneath the old ruins!",
        "The tavern keeper's daughter is looking for brave adventurers...",
    ]
    
    keyboard = [
        [InlineKeyboardButton("Hear Another Rumor", callback_data='tavern_rumors')],
        [InlineKeyboardButton("Back", callback_data='tavern_back')],
    ]
    
    query.edit_message_text(
        "🗣️ *Tavern Rumors* 🗣️\n\n"
        f"{random.choice(rumors)}",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

def tavern_back(update, context):
    """Go back to tavern menu"""
    query = update.callback_query
    query.answer()
    tavern(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("tavern", tavern))
    dp.add_handler(CallbackQueryHandler(show_drinks, pattern='^tavern_drinks$'))
    dp.add_handler(CallbackQueryHandler(buy_drink, pattern='^tavern_buy_'))
    dp.add_handler(CallbackQueryHandler(play_dice, pattern='^tavern_dice$'))
    dp.add_handler(CallbackQueryHandler(hear_rumors, pattern='^tavern_rumors$'))
    dp.add_handler(CallbackQueryHandler(tavern_back, pattern='^tavern_back$'))