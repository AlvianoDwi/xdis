from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler, ConversationHandler
from database.database import Session
from database.models import User, Guild, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

# Conversation states for guild creation
GUILD_NAME, GUILD_DESC, GUILD_CONFIRM = range(3)

@log_command
def guilds(update, context):
    """Show guild commands"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    keyboard = []
    
    if user.guild:
        # User is in a guild
        keyboard.extend([
            [InlineKeyboardButton("Guild Info", callback_data='guild_info')],
            [InlineKeyboardButton("Guild Members", callback_data='guild_members')],
            [InlineKeyboardButton("Guild Treasury", callback_data='guild_treasury')],
        ])
        
        if user.guild.leader_id == user.id:
            # User is guild leader
            keyboard.extend([
                [InlineKeyboardButton("Manage Guild", callback_data='guild_manage')],
                [InlineKeyboardButton("Disband Guild", callback_data='guild_disband')],
            ])
        else:
            # Regular member
            keyboard.append(
                [InlineKeyboardButton("Leave Guild", callback_data='guild_leave')]
            )
    else:
        # User is not in a guild
        keyboard.extend([
            [InlineKeyboardButton("Create Guild", callback_data='guild_create')],
            [InlineKeyboardButton("Join Guild", callback_data='guild_join')],
            [InlineKeyboardButton("Browse Guilds", callback_data='guild_browse')],
        ])
    
    update.message.reply_text(
        "🏛️ *Guild Menu* 🏛️\n\n"
        "Join or create a guild to collaborate with other players:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_info(update, context):
    """Show guild information"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    guild = user.guild
    leader = session.query(User).get(guild.leader_id)
    
    # Count members
    member_count = session.query(User).filter(User.guild_id == guild.id).count()
    
    message = (
        f"🏛️ *{guild.name}* 🏛️\n\n"
        f"📜 *Description:* {guild.description}\n"
        f"⭐ *Level:* {guild.level}\n"
        f"💰 *Treasury:* {format_coins(guild.treasury)}\n"
        f"👑 *Leader:* {leader.username or leader.first_name}\n"
        f"👥 *Members:* {member_count}\n"
        f"🏰 *Faction:* {guild.faction or 'Neutral'}\n"
    )
    
    keyboard = [
        [InlineKeyboardButton("Back to Guild Menu", callback_data='guild_back')],
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_members(update, context):
    """Show guild members"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    guild = user.guild
    members = session.query(User).filter(User.guild_id == guild.id).order_by(User.level.desc()).all()
    
    message = f"👥 *{guild.name} Members* 👥\n\n"
    for member in members:
        leader_flag = " 👑" if member.id == guild.leader_id else ""
        message += (
            f"• {member.username or member.first_name} "
            f"(Lv. {member.level}{leader_flag})\n"
        )
    
    keyboard = [
        [InlineKeyboardButton("Back to Guild Info", callback_data='guild_info')],
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_treasury(update, context):
    """Show guild treasury options"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    guild = user.guild
    
    message = (
        f"💰 *{guild.name} Treasury* 💰\n\n"
        f"Current funds: {format_coins(guild.treasury)}\n\n"
        "What would you like to do?"
    )
    
    keyboard = [
        [InlineKeyboardButton("Donate", callback_data='guild_donate')],
    ]
    
    if user.id == guild.leader_id:
        keyboard.append(
            [InlineKeyboardButton("Withdraw", callback_data='guild_withdraw')]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Back to Guild Info", callback_data='guild_info')]
    )
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_donate(update, context):
    """Initiate guild donation"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    # Create donation amount options
    amounts = [
        math.ceil(user.coins * 0.1),
        math.ceil(user.coins * 0.25),
        math.ceil(user.coins * 0.5),
        100,
        500,
        1000
    ]
    amounts = sorted(list(set([a for a in amounts if a > 0])))  # Remove duplicates and zeros
    
    keyboard = []
    row = []
    for amount in amounts:
        if amount <= user.coins:
            row.append(InlineKeyboardButton(
                format_coins(amount),
                callback_data=f'guild_donate_{amount}'
            ))
            if len(row) == 2:
                keyboard.append(row)
                row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='guild_donate_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='guild_treasury')])
    
    query.edit_message_text(
        "How much would you like to donate to the guild treasury?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_donation(update, context):
    """Process guild donation"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'guild_donate_custom':
        query.edit_message_text(
            "Please enter the amount you want to donate:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='guild_treasury')]
            ])
        )
        return
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if amount <= 0:
        query.edit_message_text("Amount must be positive!")
        session.close()
        return
    
    if user.coins < amount:
        query.edit_message_text("You don't have enough coins!")
        session.close()
        return
    
    # Process donation
    user.coins -= amount
    user.guild.treasury += amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=amount,
        type="guild_donation",
        details={"guild_id": user.guild.id}
    )
    session.add(transaction)
    
    # Calculate reputation gain
    rep_gain = min(5, amount // 100)
    user.reputation += rep_gain
    
    session.commit()
    
    query.edit_message_text(
        f"You donated {format_coins(amount)} to the guild treasury!\n"
        f"New treasury balance: {format_coins(user.guild.treasury)}\n"
        f"➕ Gained {rep_gain} reputation",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_custom_donation(update, context):
    """Process custom guild donation amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount <= 0:
            update.message.reply_text("Amount must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user or not user.guild:
            update.message.reply_text("You're not in a guild!")
            session.close()
            return
        
        if user.coins < amount:
            update.message.reply_text("You don't have enough coins!")
            session.close()
            return
        
        # Process donation
        user.coins -= amount
        user.guild.treasury += amount
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            amount=amount,
            type="guild_donation",
            details={"guild_id": user.guild.id, "custom": True}
        )
        session.add(transaction)
        
        # Calculate reputation gain
        rep_gain = min(5, amount // 100)
        user.reputation += rep_gain
        
        session.commit()
        
        update.message.reply_text(
            f"You donated {format_coins(amount)} to the guild treasury!\n"
            f"New treasury balance: {format_coins(user.guild.treasury)}\n"
            f"➕ Gained {rep_gain} reputation",
            parse_mode=ParseMode.MARKDOWN
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")

def guild_withdraw(update, context):
    """Guild leader withdraw from treasury"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can withdraw funds!")
        session.close()
        return
    
    guild = user.guild
    
    # Create withdraw amount options
    amounts = [
        math.ceil(guild.treasury * 0.1),
        math.ceil(guild.treasury * 0.25),
        math.ceil(guild.treasury * 0.5),
        100,
        500,
        1000
    ]
    amounts = sorted(list(set([a for a in amounts if a > 0 and a <= guild.treasury])))
    
    keyboard = []
    row = []
    for amount in amounts:
        row.append(InlineKeyboardButton(
            format_coins(amount),
            callback_data=f'guild_withdraw_{amount}'
        ))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='guild_withdraw_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='guild_treasury')])
    
    query.edit_message_text(
        "How much would you like to withdraw from the guild treasury?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_withdrawal(update, context):
    """Process guild treasury withdrawal"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'guild_withdraw_custom':
        query.edit_message_text(
            "Please enter the amount you want to withdraw:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='guild_treasury')]
            ])
        )
        return
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can withdraw funds!")
        session.close()
        return
    
    if amount <= 0:
        query.edit_message_text("Amount must be positive!")
        session.close()
        return
    
    if user.guild.treasury < amount:
        query.edit_message_text("The guild doesn't have enough funds!")
        session.close()
        return
    
    # Process withdrawal
    user.coins += amount
    user.guild.treasury -= amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=amount,
        type="guild_withdrawal",
        details={"guild_id": user.guild.id}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"You withdrew {format_coins(amount)} from the guild treasury!\n"
        f"New treasury balance: {format_coins(user.guild.treasury)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_custom_withdrawal(update, context):
    """Process custom guild withdrawal amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount <= 0:
            update.message.reply_text("Amount must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user or not user.guild:
            update.message.reply_text("You're not in a guild!")
            session.close()
            return
        
        if user.guild.leader_id != user.id:
            update.message.reply_text("Only the guild leader can withdraw funds!")
            session.close()
            return
        
        if user.guild.treasury < amount:
            update.message.reply_text("The guild doesn't have enough funds!")
            session.close()
            return
        
        # Process withdrawal
        user.coins += amount
        user.guild.treasury -= amount
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            amount=amount,
            type="guild_withdrawal",
            details={"guild_id": user.guild.id, "custom": True}
        )
        session.add(transaction)
        session.commit()
        
        update.message.reply_text(
            f"You withdrew {format_coins(amount)} from the guild treasury!\n"
            f"New treasury balance: {format_coins(user.guild.treasury)}",
            parse_mode=ParseMode.MARKDOWN
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")

def guild_manage(update, context):
    """Guild management options for leader"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can manage the guild!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Change Description", callback_data='guild_change_desc')],
        [InlineKeyboardButton("Change Faction", callback_data='guild_change_faction')],
        [InlineKeyboardButton("Kick Member", callback_data='guild_kick_member')],
        [InlineKeyboardButton("Transfer Leadership", callback_data='guild_transfer_leadership')],
        [InlineKeyboardButton("Back to Guild Menu", callback_data='guild_back')],
    ]
    
    query.edit_message_text(
        "⚙️ *Guild Management* ⚙️\n\n"
        "Manage your guild settings:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_change_description(update, context):
    """Initiate changing guild description"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can change the description!")
        session.close()
        return
    
    query.edit_message_text(
        "Please enter the new guild description:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Cancel", callback_data='guild_manage')]
        ])
    )
    session.close()
    return GUILD_DESC

def process_description_change(update, context):
    """Process guild description change"""
    user_id = update.message.from_user.id
    new_description = update.message.text
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        update.message.reply_text("You're not in a guild!")
        session.close()
        return ConversationHandler.END
    
    if user.guild.leader_id != user.id:
        update.message.reply_text("Only the guild leader can change the description!")
        session.close()
        return ConversationHandler.END
    
    if len(new_description) > 200:
        update.message.reply_text("Description must be 200 characters or less!")
        session.close()
        return GUILD_DESC
    
    # Update description
    user.guild.description = new_description
    session.commit()
    
    update.message.reply_text(
        "Guild description updated successfully!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Management", callback_data='guild_manage')]
        ])
    )
    session.close()
    return ConversationHandler.END

def guild_change_faction(update, context):
    """Change guild faction"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can change the faction!")
        session.close()
        return
    
    # Available factions
    factions = [
        "Kingdom of Alderan",
        "Empire of Valtoria",
        "Free Cities Alliance",
        "Neutral"
    ]
    
    keyboard = []
    for faction in factions:
        keyboard.append(
            [InlineKeyboardButton(faction, callback_data=f'guild_setfaction_{faction}')]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Cancel", callback_data='guild_manage')]
    )
    
    query.edit_message_text(
        "Select a new faction for your guild:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_faction_change(update, context):
    """Process guild faction change"""
    query = update.callback_query
    query.answer()
    
    new_faction = query.data.split('_', 2)[2]
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can change the faction!")
        session.close()
        return
    
    # Update faction
    user.guild.faction = new_faction if new_faction != "Neutral" else None
    session.commit()
    
    query.edit_message_text(
        f"Guild faction changed to {new_faction}!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Management", callback_data='guild_manage')]
        ])
    )
    session.close()

def guild_kick_member(update, context):
    """Initiate kicking a guild member"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can kick members!")
        session.close()
        return
    
    guild = user.guild
    members = session.query(User).filter(
        User.guild_id == guild.id,
        User.id != user.id  # Can't kick yourself
    ).order_by(User.username).all()
    
    if not members:
        query.edit_message_text("There are no other members to kick!")
        session.close()
        return
    
    keyboard = []
    for member in members:
        keyboard.append(
            [InlineKeyboardButton(
                member.username or member.first_name,
                callback_data=f'guild_kick_{member.id}'
            )]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Cancel", callback_data='guild_manage')]
    )
    
    query.edit_message_text(
        "Select a member to kick from the guild:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_kick_member(update, context):
    """Process kicking a guild member"""
    query = update.callback_query
    query.answer()
    
    member_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can kick members!")
        session.close()
        return
    
    member = session.query(User).get(member_id)
    if not member or member.guild_id != user.guild_id:
        query.edit_message_text("Member not found in your guild!")
        session.close()
        return
    
    # Kick member
    member.guild_id = None
    session.commit()
    
    query.edit_message_text(
        f"You have kicked {member.username or member.first_name} from the guild!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Management", callback_data='guild_manage')]
        ])
    )
    session.close()

def guild_transfer_leadership(update, context):
    """Initiate transferring guild leadership"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can transfer leadership!")
        session.close()
        return
    
    guild = user.guild
    members = session.query(User).filter(
        User.guild_id == guild.id,
        User.id != user.id  # Can't transfer to yourself
    ).order_by(User.username).all()
    
    if not members:
        query.edit_message_text("There are no other members to transfer leadership to!")
        session.close()
        return
    
    keyboard = []
    for member in members:
        keyboard.append(
            [InlineKeyboardButton(
                member.username or member.first_name,
                callback_data=f'guild_transfer_{member.id}'
            )]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Cancel", callback_data='guild_manage')]
    )
    
    query.edit_message_text(
        "Select a member to transfer guild leadership to:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_leadership_transfer(update, context):
    """Process transferring guild leadership"""
    query = update.callback_query
    query.answer()
    
    new_leader_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can transfer leadership!")
        session.close()
        return
    
    new_leader = session.query(User).get(new_leader_id)
    if not new_leader or new_leader.guild_id != user.guild_id:
        query.edit_message_text("Member not found in your guild!")
        session.close()
        return
    
    # Transfer leadership
    user.guild.leader_id = new_leader.id
    session.commit()
    
    query.edit_message_text(
        f"You have transferred guild leadership to {new_leader.username or new_leader.first_name}!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Guild Menu", callback_data='guild_back')]
        ])
    )
    session.close()

def guild_disband(update, context):
    """Confirm guild disband"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can disband the guild!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Confirm Disband", callback_data='guild_confirm_disband')],
        [InlineKeyboardButton("Cancel", callback_data='guild_manage')],
    ]
    
    query.edit_message_text(
        "⚠️ *Warning* ⚠️\n\n"
        "Are you sure you want to disband the guild?\n"
        "This cannot be undone and all guild funds will be lost!",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_guild_disband(update, context):
    """Process guild disband"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id != user.id:
        query.edit_message_text("Only the guild leader can disband the guild!")
        session.close()
        return
    
    guild = user.guild
    
    # Remove all members from guild
    session.query(User).filter(User.guild_id == guild.id).update({User.guild_id: None})
    
    # Delete guild
    session.delete(guild)
    session.commit()
    
    query.edit_message_text(
        "The guild has been disbanded!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Guild Menu", callback_data='guild_back')]
        ])
    )
    session.close()

def guild_leave(update, context):
    """Confirm leaving guild"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id == user.id:
        query.edit_message_text("You can't leave as guild leader! Transfer leadership first.")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Confirm Leave", callback_data='guild_confirm_leave')],
        [InlineKeyboardButton("Cancel", callback_data='guild_back')],
    ]
    
    query.edit_message_text(
        "Are you sure you want to leave the guild?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_guild_leave(update, context):
    """Process leaving guild"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.guild:
        query.edit_message_text("You're not in a guild!")
        session.close()
        return
    
    if user.guild.leader_id == user.id:
        query.edit_message_text("You can't leave as guild leader! Transfer leadership first.")
        session.close()
        return
    
    guild_name = user.guild.name
    user.guild_id = None
    session.commit()
    
    query.edit_message_text(
        f"You have left {guild_name}!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Guild Menu", callback_data='guild_back')]
        ])
    )
    session.close()

def guild_create_start(update, context):
    """Start guild creation process"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    if user.guild:
        query.edit_message_text("You're already in a guild!")
        session.close()
        return
    
    # Check creation cost
    creation_cost = 1000
    if user.coins < creation_cost:
        query.edit_message_text(
            f"You need {format_coins(creation_cost)} to create a guild!\n"
            f"Current coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    query.edit_message_text(
        "Please enter a name for your new guild (3-20 characters):",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Cancel", callback_data='guild_back')]
        ])
    )
    session.close()
    return GUILD_NAME

def process_guild_name(update, context):
    """Process guild name input"""
    user_id = update.message.from_user.id
    guild_name = update.message.text
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return ConversationHandler.END
    
    if user.guild:
        update.message.reply_text("You're already in a guild!")
        session.close()
        return ConversationHandler.END
    
    # Validate name
    if len(guild_name) < 3 or len(guild_name) > 20:
        update.message.reply_text("Guild name must be between 3 and 20 characters!")
        session.close()
        return GUILD_NAME
    
    # Check if name is taken
    existing_guild = session.query(Guild).filter(Guild.name.ilike(guild_name)).first()
    if existing_guild:
        update.message.reply_text("That guild name is already taken!")
        session.close()
        return GUILD_NAME
    
    context.user_data['guild_name'] = guild_name
    
    update.message.reply_text(
        "Please enter a description for your guild (max 200 characters):",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Cancel", callback_data='guild_back')]
        ])
    )
    session.close()
    return GUILD_DESC

def process_guild_desc(update, context):
    """Process guild description input"""
    user_id = update.message.from_user.id
    guild_desc = update.message.text
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return ConversationHandler.END
    
    if user.guild:
        update.message.reply_text("You're already in a guild!")
        session.close()
        return ConversationHandler.END
    
    if 'guild_name' not in context.user_data:
        update.message.reply_text("Error: Guild name not set. Please start over.")
        session.close()
        return ConversationHandler.END
    
    # Validate description
    if len(guild_desc) > 200:
        update.message.reply_text("Description must be 200 characters or less!")
        session.close()
        return GUILD_DESC
    
    context.user_data['guild_desc'] = guild_desc
    
    # Show confirmation
    keyboard = [
        [InlineKeyboardButton("Confirm", callback_data='guild_confirm_create')],
        [InlineKeyboardButton("Cancel", callback_data='guild_back')],
    ]
    
    update.message.reply_text(
        f"🏛️ *New Guild Confirmation* 🏛️\n\n"
        f"Name: {context.user_data['guild_name']}\n"
        f"Description: {guild_desc}\n\n"
        f"Creation cost: {format_coins(1000)}\n\n"
        "Are you sure you want to create this guild?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return GUILD_CONFIRM

def process_guild_creation(update, context):
    """Finalize guild creation"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return ConversationHandler.END
    
    if user.guild:
        query.edit_message_text("You're already in a guild!")
        session.close()
        return ConversationHandler.END
    
    if 'guild_name' not in context.user_data or 'guild_desc' not in context.user_data:
        query.edit_message_text("Error: Missing guild data. Please start over.")
        session.close()
        return ConversationHandler.END
    
    # Check creation cost again
    creation_cost = 1000
    if user.coins < creation_cost:
        query.edit_message_text(
            f"You need {format_coins(creation_cost)} to create a guild!\n"
            f"Current coins: {format_coins(user.coins)}"
        )
        session.close()
        return ConversationHandler.END
    
    # Create guild
    new_guild = Guild(
        name=context.user_data['guild_name'],
        description=context.user_data['guild_desc'],
        leader_id=user.id
    )
    session.add(new_guild)
    session.flush()  # To get the guild ID
    
    # Add user to guild
    user.guild_id = new_guild.id
    user.coins -= creation_cost
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=creation_cost,
        type="guild_creation",
        details={"guild_id": new_guild.id}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"🏛️ Guild {new_guild.name} has been created! 🏛️\n\n"
        "You are now the guild leader.\n"
        "Use /guild to manage your new guild.",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    
    # Clear temp data
    context.user_data.pop('guild_name', None)
    context.user_data.pop('guild_desc', None)
    
    return ConversationHandler.END

def guild_browse(update, context):
    """Browse available guilds"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    if user.guild:
        query.edit_message_text("You're already in a guild!")
        session.close()
        return
    
    guilds = session.query(Guild).order_by(Guild.level.desc()).limit(10).all()
    
    if not guilds:
        query.edit_message_text("There are no guilds available to join!")
        session.close()
        return
    
    message = "🏛️ *Available Guilds* 🏛️\n\n"
    for guild in guilds:
        leader = session.query(User).get(guild.leader_id)
        member_count = session.query(User).filter(User.guild_id == guild.id).count()
        message += (
            f"• *{guild.name}* (Lv. {guild.level})\n"
            f"👑 Leader: {leader.username or leader.first_name}\n"
            f"👥 Members: {member_count}\n"
            f"📜 {guild.description}\n\n"
        )
    
    keyboard = []
    for guild in guilds:
        keyboard.append(
            [InlineKeyboardButton(guild.name, callback_data=f'guild_join_{guild.id}')]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Back", callback_data='guild_back')]
    )
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_join_request(update, context):
    """Request to join a guild"""
    query = update.callback_query
    query.answer()
    
    guild_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    if user.guild:
        query.edit_message_text("You're already in a guild!")
        session.close()
        return
    
    guild = session.query(Guild).get(guild_id)
    if not guild:
        query.edit_message_text("Guild not found!")
        session.close()
        return
    
    leader = session.query(User).get(guild.leader_id)
    
    keyboard = [
        [InlineKeyboardButton("Confirm Join", callback_data=f'guild_joinconfirm_{guild.id}')],
        [InlineKeyboardButton("Cancel", callback_data='guild_browse')],
    ]
    
    query.edit_message_text(
        f"Request to join {guild.name}?\n\n"
        f"👑 Leader: {leader.username or leader.first_name}\n"
        f"📜 {guild.description}\n\n"
        "Some guilds may have requirements to join.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_guild_join(update, context):
    """Process joining a guild"""
    query = update.callback_query
    query.answer()
    
    guild_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    if user.guild:
        query.edit_message_text("You're already in a guild!")
        session.close()
        return
    
    guild = session.query(Guild).get(guild_id)
    if not guild:
        query.edit_message_text("Guild not found!")
        session.close()
        return
    
    # Check requirements
    if guild.level > 1 and user.level < guild.level:
        query.edit_message_text(
            f"This guild requires level {guild.level} to join!\n"
            f"Your level: {user.level}"
        )
        session.close()
        return
    
    # Join guild
    user.guild_id = guild.id
    session.commit()
    
    query.edit_message_text(
        f"🎉 Welcome to {guild.name}! 🎉\n\n"
        "Use /guild to see guild information and options.",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def guild_back(update, context):
    """Go back to guild menu"""
    query = update.callback_query
    query.answer()
    guilds(update, context)
    return ConversationHandler.END

def cancel_guild_creation(update, context):
    """Cancel guild creation"""
    update.message.reply_text("Guild creation cancelled.")
    context.user_data.pop('guild_name', None)
    context.user_data.pop('guild_desc', None)
    return ConversationHandler.END

def register_handlers(dp):
    dp.add_handler(CommandHandler("guild", guilds))
    
    # Guild creation conversation handler
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(guild_create_start, pattern='^guild_create$')],
        states={
            GUILD_NAME: [
                MessageHandler(Filters.text & ~Filters.command, process_guild_name),
                CallbackQueryHandler(guild_back, pattern='^guild_back$'),
            ],
            GUILD_DESC: [
                MessageHandler(Filters.text & ~Filters.command, process_guild_desc),
                CallbackQueryHandler(guild_back, pattern='^guild_back$'),
            ],
            GUILD_CONFIRM: [
                CallbackQueryHandler(process_guild_creation, pattern='^guild_confirm_create$'),
                CallbackQueryHandler(guild_back, pattern='^guild_back$'),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel_guild_creation)],
    )
    
    dp.add_handler(conv_handler)
    
    # Guild management callbacks
    dp.add_handler(CallbackQueryHandler(guild_info, pattern='^guild_info$'))
    dp.add_handler(CallbackQueryHandler(guild_members, pattern='^guild_members$'))
    dp.add_handler(CallbackQueryHandler(guild_treasury, pattern='^guild_treasury$'))
    dp.add_handler(CallbackQueryHandler(guild_manage, pattern='^guild_manage$'))
    dp.add_handler(CallbackQueryHandler(guild_disband, pattern='^guild_disband$'))
    dp.add_handler(CallbackQueryHandler(process_guild_disband, pattern='^guild_confirm_disband$'))
    dp.add_handler(CallbackQueryHandler(guild_leave, pattern='^guild_leave$'))
    dp.add_handler(CallbackQueryHandler(process_guild_leave, pattern='^guild_confirm_leave$'))
    
    # Guild treasury operations
    dp.add_handler(CallbackQueryHandler(guild_donate, pattern='^guild_donate$'))
    dp.add_handler(CallbackQueryHandler(process_donation, pattern='^guild_donate_'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_custom_donation))
    dp.add_handler(CallbackQueryHandler(guild_withdraw, pattern='^guild_withdraw$'))
    dp.add_handler(CallbackQueryHandler(process_withdrawal, pattern='^guild_withdraw_'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_custom_withdrawal))
    
    # Guild management
    dp.add_handler(CallbackQueryHandler(guild_change_description, pattern='^guild_change_desc$'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_description_change))
    dp.add_handler(CallbackQueryHandler(guild_change_faction, pattern='^guild_change_faction$'))
    dp.add_handler(CallbackQueryHandler(process_faction_change, pattern='^guild_setfaction_'))
    dp.add_handler(CallbackQueryHandler(guild_kick_member, pattern='^guild_kick_member$'))
    dp.add_handler(CallbackQueryHandler(process_kick_member, pattern='^guild_kick_'))
    dp.add_handler(CallbackQueryHandler(guild_transfer_leadership, pattern='^guild_transfer_leadership$'))
    dp.add_handler(CallbackQueryHandler(process_leadership_transfer, pattern='^guild_transfer_'))
    
    # Guild browsing and joining
    dp.add_handler(CallbackQueryHandler(guild_browse, pattern='^guild_browse$'))
    dp.add_handler(CallbackQueryHandler(guild_join_request, pattern='^guild_join_'))
    dp.add_handler(CallbackQueryHandler(process_guild_join, pattern='^guild_joinconfirm_'))
    
    # Navigation
    dp.add_handler(CallbackQueryHandler(guild_back, pattern='^guild_back$'))