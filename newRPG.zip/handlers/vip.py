from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, VIPPackage, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@log_command
def vip(update, context):
    """Show VIP information and options"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Get available VIP packages
    packages = session.query(VIPPackage).order_by(VIPPackage.price).all()
    
    # Format VIP status
    vip_status = "None"
    if user.vip_level > 0:
        vip_status = f"Level {user.vip_level}"
        if user.vip_expire:
            remaining = user.vip_expire - datetime.utcnow()
            if remaining.total_seconds() > 0:
                days = remaining.days
                hours = int(remaining.seconds // 3600)
                vip_status += f" ({days}d {hours}h remaining)"
            else:
                vip_status += " (Expired)"
    
    message = (
        "🌟 *VIP Status* 🌟\n\n"
        f"Your current VIP: {vip_status}\n\n"
        "VIP benefits include:\n"
        "• Daily bonus coins\n"
        "• Increased energy capacity\n"
        "• Exclusive items and cosmetics\n"
        "• Priority support\n\n"
        "Available VIP packages:"
    )
    
    keyboard = []
    for package in packages:
        keyboard.append([
            InlineKeyboardButton(
                f"{package.name} - {format_coins(package.price)} ({package.duration} days)",
                callback_data=f'vip_package_{package.id}'
            )
        ])
    
    keyboard.append([InlineKeyboardButton("VIP Benefits", callback_data='vip_benefits')])
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def vip_benefits(update, context):
    """Show detailed VIP benefits"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    message = (
        "✨ *VIP Benefits* ✨\n\n"
        "VIP members enjoy exclusive perks and bonuses:\n\n"
        "🌟 *VIP Level 1*\n"
        "• Daily bonus: 100 coins\n"
        "• +20 max energy\n"
        "• Access to VIP shop\n"
        "• Exclusive title\n\n"
        "💎 *VIP Level 2*\n"
        "• Daily bonus: 250 coins\n"
        "• +50 max energy\n"
        "• 10% discount in shops\n"
        "• Exclusive items\n\n"
        "👑 *VIP Level 3*\n"
        "• Daily bonus: 500 coins\n"
        "• +100 max energy\n"
        "• 20% discount in shops\n"
        "• Access to kingdom management\n"
        "• Priority support\n\n"
        "VIP status is obtained by purchasing VIP packages."
    )
    
    keyboard = [
        [InlineKeyboardButton("Back to VIP", callback_data='vip_back')],
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def vip_package_details(update, context):
    """Show details for a specific VIP package"""
    query = update.callback_query
    query.answer()
    
    package_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    package = session.query(VIPPackage).get(package_id)
    
    if not user or not package:
        query.edit_message_text("User or package not found!")
        session.close()
        return
    
    # Determine VIP level from package name
    vip_level = 1
    if "Premium" in package.name:
        vip_level = 2
    elif "Deluxe" in package.name:
        vip_level = 3
    
    message = (
        f"🌟 *{package.name}* 🌟\n\n"
        f"💰 Price: {format_coins(package.price)}\n"
        f"⏳ Duration: {package.duration} days\n"
        f"⭐ VIP Level: {vip_level}\n\n"
        "Benefits included:\n"
    )
    
    # Add package-specific benefits
    if vip_level == 1:
        message += (
            "• Daily bonus: 100 coins\n"
            "• +20 max energy\n"
            "• Access to VIP shop\n"
            "• Exclusive title\n"
        )
    elif vip_level == 2:
        message += (
            "• Daily bonus: 250 coins\n"
            "• +50 max energy\n"
            "• 10% discount in shops\n"
            "• Exclusive items\n"
        )
    elif vip_level == 3:
        message += (
            "• Daily bonus: 500 coins\n"
            "• +100 max energy\n"
            "• 20% discount in shops\n"
            "• Access to kingdom management\n"
            "• Priority support\n"
        )
    
    keyboard = []
    
    if user.coins >= package.price:
        keyboard.append([
            InlineKeyboardButton(
                f"Purchase ({format_coins(package.price)})",
                callback_data=f'vip_purchase_{package.id}'
            )
        ])
    
    keyboard.append([InlineKeyboardButton("Back to VIP", callback_data='vip_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def vip_purchase(update, context):
    """Process VIP package purchase"""
    query = update.callback_query
    query.answer()
    
    package_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    package = session.query(VIPPackage).get(package_id)
    
    if not user or not package:
        query.edit_message_text("User or package not found!")
        session.close()
        return
    
    # Determine VIP level from package name
    vip_level = 1
    if "Premium" in package.name:
        vip_level = 2
    elif "Deluxe" in package.name:
        vip_level = 3
    
    if user.coins < package.price:
        query.edit_message_text(
            f"You don't have enough coins to purchase this package!\n"
            f"Required: {format_coins(package.price)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Calculate new expiration date
    if user.vip_level >= vip_level and user.vip_expire and user.vip_expire > datetime.utcnow():
        # Extend existing VIP
        new_expire = user.vip_expire + timedelta(days=package.duration)
    else:
        # New VIP or upgrade
        new_expire = datetime.utcnow() + timedelta(days=package.duration)
    
    # Process purchase
    user.coins -= package.price
    user.vip_level = max(user.vip_level, vip_level)  # Keep higher level if already VIP
    user.vip_expire = new_expire
    
    # Adjust max energy based on VIP level
    if vip_level == 1:
        user.max_energy = max(user.max_energy, 120)
    elif vip_level == 2:
        user.max_energy = max(user.max_energy, 150)
    elif vip_level == 3:
        user.max_energy = max(user.max_energy, 200)
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=package.price,
        type="vip_purchase",
        details={"package_id": package.id, "vip_level": vip_level, "duration": package.duration}
    )
    session.add(transaction)
    session.commit()
    
    # Format expiration date
    expire_str = new_expire.strftime("%Y-%m-%d")
    
    query.edit_message_text(
        f"🎉 Congratulations! You are now VIP Level {vip_level}!\n\n"
        f"Your VIP status will expire on {expire_str}.\n"
        f"You can check your VIP benefits with /vip command.",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def vip_back(update, context):
    """Go back to VIP menu"""
    query = update.callback_query
    query.answer()
    vip(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("vip", vip))
    dp.add_handler(CallbackQueryHandler(vip_benefits, pattern='^vip_benefits$'))
    dp.add_handler(CallbackQueryHandler(vip_package_details, pattern='^vip_package_'))
    dp.add_handler(CallbackQueryHandler(vip_purchase, pattern='^vip_purchase_'))
    dp.add_handler(CallbackQueryHandler(vip_back, pattern='^vip_back$'))