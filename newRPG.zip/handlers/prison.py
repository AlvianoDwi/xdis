from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, PrisonJob, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command, restricted
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@restricted
@log_command
def imprison(update, context):
    """Imprison a player (admin only)"""
    if len(context.args) < 1:
        update.message.reply_text("Usage: /imprison <user_id> [hours] [reason]")
        return
    
    try:
        user_id = int(context.args[0])
        hours = int(context.args[1]) if len(context.args) > 1 else 24
        reason = " ".join(context.args[2:]) if len(context.args) > 2 else "Unspecified"
    except (ValueError, IndexError):
        update.message.reply_text("Invalid arguments! Usage: /imprison <user_id> [hours] [reason]")
        return
    
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    if user.jailed:
        update.message.reply_text("This user is already jailed!")
        session.close()
        return
    
    # Imprison user
    user.jailed = True
    user.jail_time = datetime.utcnow() + timedelta(hours=hours)
    user.jail_reason = reason
    session.commit()
    
    # Notify admin
    update.message.reply_text(
        f"User {user.username or user.first_name} has been jailed for {hours} hours.\n"
        f"Reason: {reason}"
    )
    
    # Notify user if possible
    try:
        context.bot.send_message(
            chat_id=user_id,
            text=f"⚖️ You have been imprisoned for {hours} hours!\n"
                 f"Reason: {reason}\n\n"
                 f"Use /prison to see your sentence and work options."
        )
    except Exception as e:
        logger.warning(f"Could not notify jailed user: {e}")
    
    session.close()

@restricted
@log_command
def release(update, context):
    """Release a player from prison (admin only)"""
    if len(context.args) < 1:
        update.message.reply_text("Usage: /release <user_id>")
        return
    
    try:
        user_id = int(context.args[0])
    except ValueError:
        update.message.reply_text("Invalid user ID!")
        return
    
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    if not user.jailed:
        update.message.reply_text("This user is not jailed!")
        session.close()
        return
    
    # Release user
    user.jailed = False
    user.jail_time = None
    user.jail_reason = None
    session.commit()
    
    # Notify admin
    update.message.reply_text(
        f"User {user.username or user.first_name} has been released from prison."
    )
    
    # Notify user if possible
    try:
        context.bot.send_message(
            chat_id=user_id,
            text="⚖️ You have been released from prison!\n"
                 "You are now a free citizen again."
        )
    except Exception as e:
        logger.warning(f"Could not notify released user: {e}")
    
    session.close()

def prison_status(update, context):
    """Show prison status for jailed player"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    if not user.jailed:
        update.message.reply_text("You are not in prison!")
        session.close()
        return
    
    time_left = user.jail_time - datetime.utcnow()
    hours_left = max(0, int(time_left.total_seconds() // 3600))
    minutes_left = max(0, int((time_left.total_seconds() % 3600) // 60))
    
    message = (
        "⛓️ *Prison Status* ⛓️\n\n"
        f"📜 *Reason:* {user.jail_reason}\n"
        f"⏳ *Time remaining:* {hours_left}h {minutes_left}m\n\n"
        "While in prison, you can work to reduce your sentence "
        "and earn some coins.\n"
        "Your crime level will also decrease over time."
    )
    
    keyboard = [
        [InlineKeyboardButton("Prison Jobs", callback_data='prison_jobs')],
        [InlineKeyboardButton("Check Crime Level", callback_data='prison_crime')],
    ]
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def prison_jobs(update, context):
    """Show available prison jobs"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.jailed:
        query.edit_message_text("You are not in prison!")
        session.close()
        return
    
    jobs = session.query(PrisonJob).all()
    
    message = "⛏️ *Prison Jobs* ⛏️\n\n"
    message += "Working will reduce your sentence and crime level.\n\n"
    
    for job in jobs:
        message += (
            f"*{job.name}*\n"
            f"📝 {job.description}\n"
            f"💰 Reward: {format_coins(job.reward)} per hour\n"
            f"⚡ Energy cost: {job.energy_cost}\n"
            f"🛑 Crime reduction: {job.crime_reduction} points\n\n"
        )
    
    keyboard = []
    for job in jobs:
        keyboard.append(
            [InlineKeyboardButton(f"Work as {job.name}", callback_data=f'prison_work_{job.id}')]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Back", callback_data='prison_back')]
    )
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def prison_work(update, context):
    """Perform prison work"""
    query = update.callback_query
    query.answer()
    
    job_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.jailed:
        query.edit_message_text("You are not in prison!")
        session.close()
        return
    
    job = session.query(PrisonJob).get(job_id)
    if not job:
        query.edit_message_text("Job not found!")
        session.close()
        return
    
    # Check energy
    if user.energy < job.energy_cost:
        query.edit_message_text(
            f"You need {job.energy_cost} energy to work as {job.name}!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Calculate work results
    reward = job.reward
    crime_reduction = job.crime_reduction
    time_reduction = timedelta(minutes=30)  # 30 minutes per work
    
    # Apply work results
    user.energy -= job.energy_cost
    user.coins += reward
    user.crime_level = max(0, user.crime_level - crime_reduction)
    
    # Reduce sentence
    if user.jail_time > datetime.utcnow():
        new_jail_time = user.jail_time - time_reduction
        if new_jail_time < datetime.utcnow():
            user.jailed = False
            user.jail_time = None
            user.jail_reason = None
            released = True
        else:
            user.jail_time = new_jail_time
            released = False
    else:
        released = True
        user.jailed = False
        user.jail_time = None
        user.jail_reason = None
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=reward,
        type="prison_work",
        details={"job_id": job.id, "job_name": job.name}
    )
    session.add(transaction)
    session.commit()
    
    # Prepare message
    message = (
        f"⛏️ You worked as {job.name} and earned {format_coins(reward)}!\n"
        f"🛑 Your crime level decreased by {crime_reduction} points.\n"
    )
    
    if released:
        message += "\n🎉 You have served your sentence and are now free!"
    else:
        time_left = user.jail_time - datetime.utcnow()
        hours_left = max(0, int(time_left.total_seconds() // 3600))
        minutes_left = max(0, int((time_left.total_seconds() % 3600) // 60))
        message += f"\n⏳ Sentence reduced! Time remaining: {hours_left}h {minutes_left}m"
    
    query.edit_message_text(
        message,
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def prison_crime_level(update, context):
    """Show player's crime level"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.jailed:
        query.edit_message_text("You are not in prison!")
        session.close()
        return
    
    message = (
        "🛑 *Crime Level* 🛑\n\n"
        f"Your current crime level: {user.crime_level}/100\n\n"
        "Crime level affects how you're perceived in society.\n"
        "Higher levels may result in:\n"
        "• Longer prison sentences\n"
        "• Higher fines\n"
        "• Difficulty finding legitimate work\n\n"
        "Your crime level will decrease over time and through prison work."
    )
    
    keyboard = [
        [InlineKeyboardButton("Back", callback_data='prison_back')],
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def prison_back(update, context):
    """Go back to prison status"""
    query = update.callback_query
    query.answer()
    prison_status(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("imprison", imprison))
    dp.add_handler(CommandHandler("release", release))
    dp.add_handler(CommandHandler("prison", prison_status))
    
    dp.add_handler(CallbackQueryHandler(prison_jobs, pattern='^prison_jobs$'))
    dp.add_handler(CallbackQueryHandler(prison_work, pattern='^prison_work_'))
    dp.add_handler(CallbackQueryHandler(prison_crime_level, pattern='^prison_crime$'))
    dp.add_handler(CallbackQueryHandler(prison_back, pattern='^prison_back$'))