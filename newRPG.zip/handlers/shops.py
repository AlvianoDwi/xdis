from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler, ConversationHandler
from database.database import Session
from database.models import Shop, ShopItem, User, InventoryItem
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

# Shop states
SHOPPING, VIEWING_SHOP_ITEM = range(2)

@log_command
def shops(update, context):
    """List available shops in the game"""
    session = Session()
    shops = session.query(Shop).all()
    
    message = "🏬 *Shops Directory* 🏬\n\n"
    message += "Visit specialized shops for unique items:\n\n"
    
    keyboard = []
    for shop in shops:
        keyboard.append(
            [InlineKeyboardButton(shop.name, callback_data=f'shop_enter_{shop.id}')]
        )
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return SHOPPING

def enter_shop(update, context):
    """Enter a specific shop"""
    query = update.callback_query
    query.answer()
    
    shop_id = int(query.data.split('_')[2])
    session = Session()
    shop = session.query(Shop).get(shop_id)
    
    if not shop:
        query.edit_message_text("Shop not found!")
        session.close()
        return ConversationHandler.END
    
    items = session.query(ShopItem).filter(
        ShopItem.shop_id == shop_id
    ).order_by(ShopItem.item.has(Item.type)).all()
    
    message = f"🏬 *{shop.name}* 🏬\n\n"
    message += f"{shop.description}\n\n"
    message += "Available items:\n\n"
    
    for item in items:
        price = item.price
        # Apply VIP discount if applicable
        user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
        if user and user.vip_level > 0:
            discount = VIP_LEVELS[user.vip_level]['shop_discount']
            price = int(price * (1 - discount/100))
        
        message += (
            f"• *{item.item.name}* - {format_coins(price)}\n"
            f"  {item.item.description}\n\n"
        )
    
    keyboard = []
    for item in items:
        keyboard.append(
            [InlineKeyboardButton(item.item.name, callback_data=f'shop_item_{item.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back to Shops", callback_data='shops_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return VIEWING_SHOP_ITEM

def view_shop_item(update, context):
    """View details of a shop item"""
    query = update.callback_query
    query.answer()
    
    item_id = int(query.data.split('_')[2])
    session = Session()
    shop_item = session.query(ShopItem).get(item_id)
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    if not shop_item or not user:
        query.edit_message_text("Item or user not found!")
        session.close()
        return ConversationHandler.END
    
    # Calculate price with possible VIP discount
    price = shop_item.price
    if user.vip_level > 0:
        discount = VIP_LEVELS[user.vip_level]['shop_discount']
        price = int(price * (1 - discount/100))
    
    message = (
        f"🛍️ *{shop_item.item.name}* 🛍️\n\n"
        f"📜 *Description:* {shop_item.item.description}\n"
        f"💰 *Price:* {format_coins(price)}\n"
    )
    
    if user.vip_level > 0:
        message += f"🎁 *VIP Discount:* {discount}%\n\n"
    
    if shop_item.item.stats:
        message += "*Attributes:*\n"
        for stat, value in shop_item.item.stats.items():
            message += f"• {stat.replace('_', ' ').title()}: {value}\n"
        message += "\n"
    
    keyboard = []
    
    if user.coins >= price:
        keyboard.append(
            [InlineKeyboardButton("Purchase", callback_data=f'shop_purchase_{shop_item.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back to Shop", callback_data=f'shop_back_{shop_item.shop_id}')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return VIEWING_SHOP_ITEM

def purchase_shop_item(update, context):
    """Purchase an item from a shop"""
    query = update.callback_query
    query.answer()
    
    shop_item_id = int(query.data.split('_')[2])
    session = Session()
    shop_item = session.query(ShopItem).get(shop_item_id)
    user = session.query(User).filter(User.telegram_id == query.from_user.id).first()
    
    if not shop_item or not user:
        query.edit_message_text("Item or user not found!")
        session.close()
        return ConversationHandler.END
    
    # Calculate price with possible VIP discount
    price = shop_item.price
    if user.vip_level > 0:
        discount = VIP_LEVELS[user.vip_level]['shop_discount']
        price = int(price * (1 - discount/100))
    
    if user.coins < price:
        query.edit_message_text(
            f"You don't have enough coins to buy this!\n"
            f"Price: {format_coins(price)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return VIEWING_SHOP_ITEM
    
    # Process purchase
    user.coins -= price
    
    # Add item to inventory
    existing_item = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.item_id == shop_item.item_id
    ).first()
    
    if existing_item:
        existing_item.quantity += 1
    else:
        new_item = InventoryItem(
            user_id=user.id,
            item_id=shop_item.item_id,
            quantity=1,
            durability=shop_item.item.durability,
            max_durability=shop_item.item.durability
        )
        session.add(new_item)
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=price,
        type="shop_purchase",
        item_id=shop_item.item_id,
        quantity=1,
        details={
            "shop_id": shop_item.shop_id,
            "original_price": shop_item.price,
            "discounted_price": price
        }
    )
    session.add(transaction)
    
    session.commit()
    
    query.edit_message_text(
        f"🎉 You purchased {shop_item.item.name} for {format_coins(price)}!\n"
        f"New balance: {format_coins(user.coins)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return ConversationHandler.END

def shop_back(update, context):
    """Return to shop view"""
    query = update.callback_query
    query.answer()
    
    shop_id = int(query.data.split('_')[2])
    session = Session()
    shop = session.query(Shop).get(shop_id)
    
    if not shop:
        query.edit_message_text("Shop not found!")
        session.close()
        return ConversationHandler.END
    
    # Reuse enter_shop function to return to the shop
    enter_shop(update, context)
    return VIEWING_SHOP_ITEM

def shops_back(update, context):
    """Return to shops list"""
    query = update.callback_query
    query.answer()
    shops(update, context)
    return SHOPPING

def cancel_shopping(update, context):
    """Cancel shopping interaction"""
    update.message.reply_text("Shopping cancelled.")
    return ConversationHandler.END

def register_handlers(dp):
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("shops", shops)],
        states={
            SHOPPING: [
                CallbackQueryHandler(enter_shop, pattern='^shop_enter_'),
                CallbackQueryHandler(shops_back, pattern='^shops_back$'),
            ],
            VIEWING_SHOP_ITEM: [
                CallbackQueryHandler(view_shop_item, pattern='^shop_item_'),
                CallbackQueryHandler(purchase_shop_item, pattern='^shop_purchase_'),
                CallbackQueryHandler(shop_back, pattern='^shop_back_'),
                CallbackQueryHandler(shops_back, pattern='^shops_back$'),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel_shopping)],
    )
    
    dp.add_handler(conv_handler)