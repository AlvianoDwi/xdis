from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, RobberyRecord, Kingdom
from utils.helpers import format_coins
from utils.decorators import log_command
import logging
import random

logger = logging.getLogger(__name__)

@log_command
def rob(update, context):
    """Initiate robbery attempt"""
    if len(context.args) < 1:
        update.message.reply_text("Usage: /rob <user_id>")
        return
    
    try:
        target_id = int(context.args[0])
    except ValueError:
        update.message.reply_text("Invalid user ID! Usage: /rob <user_id>")
        return
    
    robber_id = update.effective_user.id
    if robber_id == target_id:
        update.message.reply_text("You can't rob yourself!")
        return
    
    session = Session()
    robber = session.query(User).filter(User.telegram_id == robber_id).first()
    target = session.query(User).filter(User.telegram_id == target_id).first()
    
    if not robber or not target:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    if robber.jailed:
        update.message.reply_text("You can't rob people while in prison!")
        session.close()
        return
    
    if target.jailed:
        update.message.reply_text("You can't rob someone who's in prison!")
        session.close()
        return
    
    # Check robbery cooldown (once per hour per target)
    last_robbery = session.query(RobberyRecord).filter(
        RobberyRecord.robber_id == robber.id,
        RobberyRecord.victim_id == target.id
    ).order_by(RobberyRecord.timestamp.desc()).first()
    
    if last_robbery and (datetime.utcnow() - last_robbery.timestamp).total_seconds() < 3600:
        update.message.reply_text(
            f"You can only rob this person once per hour!\n"
            f"Next attempt available in {60 - int((datetime.utcnow() - last_robbery.timestamp).total_seconds() // 60)} minutes."
        )
        session.close()
        return
    
    # Check target has coins
    if target.coins < 10:
        update.message.reply_text("This person doesn't have enough coins to rob!")
        session.close()
        return
    
    # Calculate success chance
    base_chance = 0.5  # 50% base chance
    agility_diff = (robber.agility - target.agility) * 0.01  # 1% per agility point difference
    crime_mod = robber.crime_level * 0.005  # 0.5% per crime level
    success_chance = min(0.9, max(0.1, base_chance + agility_diff + crime_mod))
    
    # Determine outcome
    success = random.random() < success_chance
    
    # Calculate amount stolen (10-50% of target's coins)
    steal_percent = random.uniform(0.1, 0.5)
    amount_stolen = min(int(target.coins * steal_percent), target.coins)
    
    if success:
        # Successful robbery
        target.coins -= amount_stolen
        robber.coins += amount_stolen
        
        # Increase crime level
        robber.crime_level = min(100, robber.crime_level + 5)
        
        # Record robbery
        record = RobberyRecord(
            robber_id=robber.id,
            victim_id=target.id,
            amount=amount_stolen,
            success=True
        )
        session.add(record)
        
        # Check kingdom laws for penalty
        kingdom = session.query(Kingdom).first()
        if kingdom and kingdom.laws and 'theft_penalty' in kingdom.laws:
            penalty = kingdom.laws['theft_penalty']
            if robber.coins >= penalty:
                robber.coins -= penalty
                kingdom.treasury += penalty
                
                # Record penalty
                penalty_transaction = Transaction(
                    user_id=robber.id,
                    amount=penalty,
                    type="crime_penalty",
                    details={"crime": "theft", "victim": target.id}
                )
                session.add(penalty_transaction)
        
        session.commit()
        
        # Notify robber
        update.message.reply_text(
            f"💰 You successfully robbed {target.username or target.first_name} "
            f"and stole {format_coins(amount_stolen)}!\n"
            f"🛑 Your crime level increased by 5 (now {robber.crime_level}/100).\n\n"
            f"{'⚠️ You were fined ' + format_coins(penalty) + ' by the kingdom!' if kingdom and kingdom.laws and 'theft_penalty' in kingdom.laws and penalty else ''}"
        )
        
        # Notify victim if possible
        try:
            context.bot.send_message(
                chat_id=target_id,
                text=f"😱 You were robbed by {robber.username or robber.first_name}!\n"
                     f"They stole {format_coins(amount_stolen)} from you!"
            )
        except Exception as e:
            logger.warning(f"Could not notify robbery victim: {e}")
    else:
        # Failed robbery
        # Small chance to be jailed (10%)
        jailed = random.random() < 0.1
        
        if jailed:
            robber.jailed = True
            robber.jail_time = datetime.utcnow() + timedelta(hours=2)
            robber.jail_reason = f"Attempted robbery of {target.username or target.first_name}"
            
            # Check kingdom laws for penalty
            kingdom = session.query(Kingdom).first()
            if kingdom and kingdom.laws and 'theft_penalty' in kingdom.laws:
                penalty = kingdom.laws['theft_penalty']
                if robber.coins >= penalty:
                    robber.coins -= penalty
                    kingdom.treasury += penalty
                    
                    # Record penalty
                    penalty_transaction = Transaction(
                        user_id=robber.id,
                        amount=penalty,
                        type="crime_penalty",
                        details={"crime": "attempted_theft", "victim": target.id}
                    )
                    session.add(penalty_transaction)
        
        # Increase crime level more for failure
        robber.crime_level = min(100, robber.crime_level + 10)
        
        # Record robbery attempt
        record = RobberyRecord(
            robber_id=robber.id,
            victim_id=target.id,
            amount=0,
            success=False,
            jailed=jailed
        )
        session.add(record)
        session.commit()
        
        # Notify robber
        if jailed:
            update.message.reply_text(
                f"🚨 Your robbery attempt failed and you were caught!\n"
                f"You've been sentenced to 2 hours in prison.\n"
                f"🛑 Your crime level increased by 10 (now {robber.crime_level}/100).\n\n"
                f"{'⚠️ You were fined ' + format_coins(penalty) + ' by the kingdom!' if kingdom and kingdom.laws and 'theft_penalty' in kingdom.laws and penalty else ''}"
            )
        else:
            update.message.reply_text(
                f"😬 Your robbery attempt failed!\n"
                f"🛑 Your crime level increased by 10 (now {robber.crime_level}/100)."
            )
        
        # Notify victim if possible
        try:
            context.bot.send_message(
                chat_id=target_id,
                text=f"🚨 {robber.username or robber.first_name} tried to rob you but failed!\n"
                     f"{'They were caught and sent to prison!' if jailed else ''}"
            )
        except Exception as e:
            logger.warning(f"Could not notify robbery victim: {e}")
    
    session.close()

def register_handlers(dp):
    dp.add_handler(CommandHandler("rob", rob))