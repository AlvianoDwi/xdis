from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler
from config.config import config
from utils.logger import setup_logger
from database.database import init_db

# Import all handler modules
from handlers import (
    admin, combat, crafting, economy, farming, guilds, housing,
    jobs, kingdom, market, p2p, player, prison, quests, robbery,
    shops, skills, tavern, vip, events
)

def main():
    """Main entry point for the bot application."""
    # Set up logging
    setup_logger()
    
    # Initialize database
    init_db()
    
    # Create the Updater and pass it your bot's token
    updater = Updater(token=config.TOKEN, use_context=True)
    
    # Get the dispatcher to register handlers
    dp = updater.dispatcher
    
    # Register all command handlers
    register_command_handlers(dp)
    
    # Register all callback query handlers
    register_callback_handlers(dp)
    
    # Register all conversation handlers
    register_conversation_handlers(dp)
    
    # Register error handler
    dp.add_error_handler(error_handler)
    
    # Start the Bot
    updater.start_polling()
    
    # Run the bot until you press Ctrl-C
    updater.idle()

def register_command_handlers(dp):
    """Register all command handlers."""
    # Player commands
    dp.add_handler(CommandHandler("start", player.start))
    dp.add_handler(CommandHandler("profile", player.profile))
    dp.add_handler(CommandHandler("inventory", player.show_inventory))
    
    # Economy commands
    dp.add_handler(CommandHandler("economy", economy.economy))
    dp.add_handler(CommandHandler("market", market.market))
    dp.add_handler(CommandHandler("jobs", jobs.jobs_menu))
    
    # Crafting commands
    dp.add_handler(CommandHandler("craft", crafting.crafting_menu))
    
    # Guild commands
    dp.add_handler(CommandHandler("guild", guilds.guilds))
    
    # Kingdom commands
    dp.add_handler(CommandHandler("kingdom", kingdom.kingdom))
    
    # Housing commands
    dp.add_handler(CommandHandler("house", housing.housing))
    
    # VIP commands
    dp.add_handler(CommandHandler("vip", vip.vip))
    
    # Admin commands
    dp.add_handler(CommandHandler("admin", admin.admin_menu))
    dp.add_handler(CommandHandler("imprison", prison.imprison))
    dp.add_handler(CommandHandler("release", prison.release))

def register_callback_handlers(dp):
    """Register all callback query handlers."""
    # Player callbacks
    dp.add_handler(CallbackQueryHandler(player.show_item_details, pattern='^inv_item_'))
    dp.add_handler(CallbackQueryHandler(player.equip_item, pattern='^inv_equip_'))
    
    # Market callbacks
    dp.add_handler(CallbackQueryHandler(market.show_listing, pattern='^market_item_'))
    dp.add_handler(CallbackQueryHandler(market.buy_item, pattern='^market_buy_'))
    
    # Guild callbacks
    dp.add_handler(CallbackQueryHandler(guilds.guild_info, pattern='^guild_info_'))
    dp.add_handler(CallbackQueryHandler(guilds.guild_join, pattern='^guild_join_'))
    
    # Add more callback handlers as needed...

def register_conversation_handlers(dp):
    """Register all conversation handlers."""
    from telegram.ext import ConversationHandler
    
    # Market conversation
    market_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(market.start_selling, pattern='^market_sell$')],
        states={
            market.SELECTING_ITEM: [
                CallbackQueryHandler(market.select_item, pattern='^sell_item_')
            ],
            market.SETTING_PRICE: [
                MessageHandler(Filters.text & ~Filters.command, market.set_price)
            ],
            market.CONFIRMATION: [
                CallbackQueryHandler(market.confirm_listing, pattern='^confirm_sell_')
            ]
        },
        fallbacks=[CommandHandler('cancel', market.cancel_selling)],
    )
    dp.add_handler(market_conv)
    
    # Guild creation conversation
    guild_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(guilds.start_guild_creation, pattern='^guild_create$')],
        states={
            guilds.GUILD_NAME: [
                MessageHandler(Filters.text & ~Filters.command, guilds.process_guild_name)
            ],
            guilds.GUILD_DESC: [
                MessageHandler(Filters.text & ~Filters.command, guilds.process_guild_desc)
            ],
            guilds.GUILD_CONFIRM: [
                CallbackQueryHandler(guilds.process_guild_creation, pattern='^guild_confirm_create$')
            ]
        },
        fallbacks=[CommandHandler('cancel', guilds.cancel_guild_creation)],
    )
    dp.add_handler(guild_conv)

def error_handler(update, context):
    """Log errors and handle them gracefully."""
    from utils.logger import logger
    
    logger.error(f"Update {update} caused error {context.error}")
    
    if update and update.effective_message:
        update.effective_message.reply_text(
            "An error occurred while processing your request. "
            "Please try again later."
        )

if __name__ == '__main__':
    main()