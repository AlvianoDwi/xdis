from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CallbackQueryHandler, CommandHandler, ConversationHandler
from database.models import MarketListing, User
from database.database import Session
from utils.decorators import restricted, log_command
from utils.helpers import format_coins
import logging

logger = logging.getLogger(__name__)

# States for conversation
SELECTING_ACTION, SELECTING_ITEM, INPUT_QUANTITY, INPUT_PRICE, CONFIRM_LISTING = range(5)

@log_command
def p2p_market(update, context):
    """Show P2P market options"""
    keyboard = [
        [InlineKeyboardButton("Browse Listings", callback_data='p2p_browse')],
        [InlineKeyboardButton("Create Listing", callback_data='p2p_create')],
        [InlineKeyboardButton("My Listings", callback_data='p2p_mine')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(
        "🏰 *Medieval Marketplace* 🏰\n\n"
        "Trade goods with other players in the realm!\n"
        "Choose an option below:",
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )
    return SELECTING_ACTION

def p2p_browse(update, context):
    """Browse P2P listings"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    listings = session.query(MarketListing).filter(
        MarketListing.listing_type == 'p2p',
        MarketListing.expires_at > datetime.utcnow()
    ).limit(10).all()
    
    if not listings:
        query.edit_message_text(
            "No active listings available at the moment. "
            "Would you like to create one?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Create Listing", callback_data='p2p_create')],
                [InlineKeyboardButton("Back", callback_data='p2p_back')]
            ])
        )
        return SELECTING_ACTION
    
    # Format listings
    message = "🏰 *Active Listings* �\n\n"
    for listing in listings:
        seller = session.query(User).get(listing.seller_id)
        message += (
            f"📦 *{listing.item_id}* x{listing.quantity}\n"
            f"💰 Price: {format_coins(listing.price)}\n"
            f"👤 Seller: {seller.username or seller.first_name}\n"
            f"🕒 Expires: {listing.expires_at.strftime('%Y-%m-%d %H:%M')}\n\n"
        )
    
    keyboard = [[InlineKeyboardButton("Buy", callback_data=f'buy_{listing.id}') for listing in listings[:3]]
    keyboard.append([InlineKeyboardButton("Next Page", callback_data='p2p_next_1')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='p2p_back')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()
    return SELECTING_ACTION

# ... (more P2P functions)

def register_handlers(dp):
    dp.add_handler(CommandHandler('market', p2p_market))
    
    # Conversation handler for P2P trading
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(p2p_browse, pattern='^p2p_browse$')],
        states={
            SELECTING_ACTION: [
                CallbackQueryHandler(p2p_browse, pattern='^p2p_browse$'),
                CallbackQueryHandler(p2p_create_listing, pattern='^p2p_create$'),
                CallbackQueryHandler(p2p_my_listings, pattern='^p2p_mine$'),
                CallbackQueryHandler(p2p_back, pattern='^p2p_back$'),
            ],
            # ... other states
        },
        fallbacks=[CommandHandler('cancel', cancel_p2p)],
    )
    dp.add_handler(conv_handler)