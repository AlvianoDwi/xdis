from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, Kingdom, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

@log_command
def kingdom(update, context):
    """Show kingdom information"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Get kingdom info
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        # Create default kingdom if none exists
        kingdom = Kingdom(
            name="Kingdom of Alderan",
            description="The great kingdom where this adventure begins",
            leader_id=user.id
        )
        session.add(kingdom)
        session.commit()
    
    leader = session.query(User).get(kingdom.leader_id)
    
    # Count citizens (users with same faction)
    citizen_count = session.query(User).filter(
        User.guild.has(faction=kingdom.name)
    ).count()
    
    # Count guilds
    guild_count = session.query(Guild).filter(
        Guild.faction == kingdom.name
    ).count()
    
    message = (
        f"👑 *{kingdom.name}* 👑\n\n"
        f"📜 *Description:* {kingdom.description}\n"
        f"💰 *Treasury:* {format_coins(kingdom.treasury)}\n"
        f"🏰 *Tax Rate:* {int(kingdom.tax_rate * 100)}%\n"
        f"👑 *Monarch:* {leader.username or leader.first_name}\n"
        f"👥 *Citizens:* {citizen_count}\n"
        f"🏛️ *Guilds:* {guild_count}\n\n"
        f"📜 *Laws:*\n"
        f"• Theft penalty: {format_coins(kingdom.laws.get('theft_penalty', 0))}\n"
        f"• Murder penalty: {format_coins(kingdom.laws.get('murder_penalty', 0))}\n"
    )
    
    keyboard = []
    
    if user.id == kingdom.leader_id or user.vip_level >= 3:
        keyboard.append(
            [InlineKeyboardButton("Manage Kingdom", callback_data='kingdom_manage')]
        )
    
    keyboard.append(
        [InlineKeyboardButton("Pay Taxes", callback_data='kingdom_taxes')]
    )
    keyboard.append(
        [InlineKeyboardButton("Kingdom Quests", callback_data='kingdom_quests')]
    )
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def kingdom_manage(update, context):
    """Kingdom management options"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id and user.vip_level < 3:
        query.edit_message_text("Only the monarch or VIP members can manage the kingdom!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Change Description", callback_data='kingdom_change_desc')],
        [InlineKeyboardButton("Adjust Tax Rate", callback_data='kingdom_change_tax')],
        [InlineKeyboardButton("Update Laws", callback_data='kingdom_change_laws')],
        [InlineKeyboardButton("Treasury", callback_data='kingdom_treasury')],
        [InlineKeyboardButton("Back", callback_data='kingdom_back')],
    ]
    
    query.edit_message_text(
        "⚙️ *Kingdom Management* ⚙️\n\n"
        "Manage your kingdom's affairs:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def kingdom_treasury(update, context):
    """Kingdom treasury options"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id and user.vip_level < 3:
        query.edit_message_text("Only the monarch or VIP members can manage the treasury!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Withdraw Funds", callback_data='kingdom_withdraw')],
        [InlineKeyboardButton("Back", callback_data='kingdom_manage')],
    ]
    
    query.edit_message_text(
        f"💰 *Kingdom Treasury* 💰\n\n"
        f"Current funds: {format_coins(kingdom.treasury)}\n\n"
        "What would you like to do?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def kingdom_withdraw(update, context):
    """Withdraw from kingdom treasury"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id and user.vip_level < 3:
        query.edit_message_text("Only the monarch or VIP members can withdraw funds!")
        session.close()
        return
    
    # Create withdraw amount options
    amounts = [
        math.ceil(kingdom.treasury * 0.1),
        math.ceil(kingdom.treasury * 0.25),
        math.ceil(kingdom.treasury * 0.5),
        1000,
        5000,
        10000
    ]
    amounts = sorted(list(set([a for a in amounts if a > 0 and a <= kingdom.treasury])))
    
    keyboard = []
    row = []
    for amount in amounts:
        row.append(InlineKeyboardButton(
            format_coins(amount),
            callback_data=f'kingdom_withdraw_{amount}'
        ))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='kingdom_withdraw_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='kingdom_treasury')])
    
    query.edit_message_text(
        "How much would you like to withdraw from the kingdom treasury?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_kingdom_withdrawal(update, context):
    """Process kingdom treasury withdrawal"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'kingdom_withdraw_custom':
        query.edit_message_text(
            "Please enter the amount you want to withdraw:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='kingdom_treasury')]
            ])
        )
        return
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id and user.vip_level < 3:
        query.edit_message_text("Only the monarch or VIP members can withdraw funds!")
        session.close()
        return
    
    if amount <= 0:
        query.edit_message_text("Amount must be positive!")
        session.close()
        return
    
    if kingdom.treasury < amount:
        query.edit_message_text("The kingdom doesn't have enough funds!")
        session.close()
        return
    
    # Process withdrawal
    user.coins += amount
    kingdom.treasury -= amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=amount,
        type="kingdom_withdrawal",
        details={"kingdom_id": kingdom.id}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"You withdrew {format_coins(amount)} from the kingdom treasury!\n"
        f"New treasury balance: {format_coins(kingdom.treasury)}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_custom_kingdom_withdrawal(update, context):
    """Process custom kingdom withdrawal amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount <= 0:
            update.message.reply_text("Amount must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user:
            update.message.reply_text("User not found!")
            session.close()
            return
        
        kingdom = session.query(Kingdom).first()
        if not kingdom:
            update.message.reply_text("Kingdom not found!")
            session.close()
            return
        
        if user.id != kingdom.leader_id and user.vip_level < 3:
            update.message.reply_text("Only the monarch or VIP members can withdraw funds!")
            session.close()
            return
        
        if kingdom.treasury < amount:
            update.message.reply_text("The kingdom doesn't have enough funds!")
            session.close()
            return
        
        # Process withdrawal
        user.coins += amount
        kingdom.treasury -= amount
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            amount=amount,
            type="kingdom_withdrawal",
            details={"kingdom_id": kingdom.id, "custom": True}
        )
        session.add(transaction)
        session.commit()
        
        update.message.reply_text(
            f"You withdrew {format_coins(amount)} from the kingdom treasury!\n"
            f"New treasury balance: {format_coins(kingdom.treasury)}",
            parse_mode=ParseMode.MARKDOWN
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")

def kingdom_change_tax(update, context):
    """Change kingdom tax rate"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the tax rate!")
        session.close()
        return
    
    # Create tax rate options
    rates = [5, 10, 15, 20, 25, 30]  # percentages
    
    keyboard = []
    row = []
    for rate in rates:
        row.append(InlineKeyboardButton(
            f"{rate}%",
            callback_data=f'kingdom_settax_{rate}'
        ))
        if len(row) == 3:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='kingdom_manage')])
    
    query.edit_message_text(
        "Select a new tax rate for the kingdom:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_tax_change(update, context):
    """Process kingdom tax rate change"""
    query = update.callback_query
    query.answer()
    
    new_rate = int(query.data.split('_')[2]) / 100  # Convert to decimal
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the tax rate!")
        session.close()
        return
    
    # Update tax rate
    kingdom.tax_rate = new_rate
    session.commit()
    
    query.edit_message_text(
        f"Kingdom tax rate has been set to {int(new_rate * 100)}%!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Management", callback_data='kingdom_manage')]
        ])
    )
    session.close()

def kingdom_change_laws(update, context):
    """Change kingdom laws"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the laws!")
        session.close()
        return
    
    keyboard = [
        [InlineKeyboardButton("Set Theft Penalty", callback_data='kingdom_settheft')],
        [InlineKeyboardButton("Set Murder Penalty", callback_data='kingdom_setmurder')],
        [InlineKeyboardButton("Back", callback_data='kingdom_manage')],
    ]
    
    query.edit_message_text(
        "📜 *Law Adjustment* 📜\n\n"
        "Current penalties:\n"
        f"• Theft: {format_coins(kingdom.laws.get('theft_penalty', 0))}\n"
        f"• Murder: {format_coins(kingdom.laws.get('murder_penalty', 0))}\n\n"
        "Select a law to modify:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def set_theft_penalty(update, context):
    """Set theft penalty amount"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the laws!")
        session.close()
        return
    
    # Common penalty amounts
    amounts = [50, 100, 200, 500, 1000]
    
    keyboard = []
    row = []
    for amount in amounts:
        row.append(InlineKeyboardButton(
            format_coins(amount),
            callback_data=f'kingdom_theft_{amount}'
        ))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='kingdom_theft_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='kingdom_change_laws')])
    
    query.edit_message_text(
        "Set the penalty amount for theft crimes:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_theft_penalty(update, context):
    """Process theft penalty change"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'kingdom_theft_custom':
        query.edit_message_text(
            "Please enter the theft penalty amount:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='kingdom_change_laws')]
            ])
        )
        return
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the laws!")
        session.close()
        return
    
    if amount < 0:
        query.edit_message_text("Penalty must be positive!")
        session.close()
        return
    
    # Update law
    if not kingdom.laws:
        kingdom.laws = {}
    kingdom.laws['theft_penalty'] = amount
    session.commit()
    
    query.edit_message_text(
        f"Theft penalty has been set to {format_coins(amount)}!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Laws", callback_data='kingdom_change_laws')]
        ])
    )
    session.close()

def process_custom_theft_penalty(update, context):
    """Process custom theft penalty amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount < 0:
            update.message.reply_text("Penalty must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user:
            update.message.reply_text("User not found!")
            session.close()
            return
        
        kingdom = session.query(Kingdom).first()
        if not kingdom:
            update.message.reply_text("Kingdom not found!")
            session.close()
            return
        
        if user.id != kingdom.leader_id:
            update.message.reply_text("Only the monarch can change the laws!")
            session.close()
            return
        
        # Update law
        if not kingdom.laws:
            kingdom.laws = {}
        kingdom.laws['theft_penalty'] = amount
        session.commit()
        
        update.message.reply_text(
            f"Theft penalty has been set to {format_coins(amount)}!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Laws", callback_data='kingdom_change_laws')]
            ])
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")

def set_murder_penalty(update, context):
    """Set murder penalty amount"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the laws!")
        session.close()
        return
    
    # Common penalty amounts
    amounts = [200, 500, 1000, 2000, 5000]
    
    keyboard = []
    row = []
    for amount in amounts:
        row.append(InlineKeyboardButton(
            format_coins(amount),
            callback_data=f'kingdom_murder_{amount}'
        ))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Amount", callback_data='kingdom_murder_custom')])
    keyboard.append([InlineKeyboardButton("Back", callback_data='kingdom_change_laws')])
    
    query.edit_message_text(
        "Set the penalty amount for murder crimes:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    session.close()

def process_murder_penalty(update, context):
    """Process murder penalty change"""
    query = update.callback_query
    query.answer()
    
    if query.data == 'kingdom_murder_custom':
        query.edit_message_text(
            "Please enter the murder penalty amount:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data='kingdom_change_laws')]
            ])
        )
        return
    
    amount = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    if user.id != kingdom.leader_id:
        query.edit_message_text("Only the monarch can change the laws!")
        session.close()
        return
    
    if amount < 0:
        query.edit_message_text("Penalty must be positive!")
        session.close()
        return
    
    # Update law
    if not kingdom.laws:
        kingdom.laws = {}
    kingdom.laws['murder_penalty'] = amount
    session.commit()
    
    query.edit_message_text(
        f"Murder penalty has been set to {format_coins(amount)}!",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Laws", callback_data='kingdom_change_laws')]
        ])
    )
    session.close()

def process_custom_murder_penalty(update, context):
    """Process custom murder penalty amount"""
    user_id = update.message.from_user.id
    text = update.message.text
    
    try:
        amount = int(text)
        if amount < 0:
            update.message.reply_text("Penalty must be positive!")
            return
        
        session = Session()
        user = session.query(User).filter(User.telegram_id == user_id).first()
        
        if not user:
            update.message.reply_text("User not found!")
            session.close()
            return
        
        kingdom = session.query(Kingdom).first()
        if not kingdom:
            update.message.reply_text("Kingdom not found!")
            session.close()
            return
        
        if user.id != kingdom.leader_id:
            update.message.reply_text("Only the monarch can change the laws!")
            session.close()
            return
        
        # Update law
        if not kingdom.laws:
            kingdom.laws = {}
        kingdom.laws['murder_penalty'] = amount
        session.commit()
        
        update.message.reply_text(
            f"Murder penalty has been set to {format_coins(amount)}!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Laws", callback_data='kingdom_change_laws')]
            ])
        )
        session.close()
    except ValueError:
        update.message.reply_text("Please enter a valid number!")

def kingdom_pay_taxes(update, context):
    """Pay kingdom taxes"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    kingdom = session.query(Kingdom).first()
    if not kingdom:
        query.edit_message_text("Kingdom not found!")
        session.close()
        return
    
    # Calculate tax amount (10% of coins or fixed amount)
    tax_amount = min(math.ceil(user.coins * kingdom.tax_rate), 1000)
    
    if user.coins < tax_amount:
        query.edit_message_text(
            f"You don't have enough coins to pay taxes!\n"
            f"Required: {format_coins(tax_amount)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Pay taxes
    user.coins -= tax_amount
    kingdom.treasury += tax_amount
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=tax_amount,
        type="tax_payment",
        details={"kingdom_id": kingdom.id}
    )
    session.add(transaction)
    
    # Gain reputation
    rep_gain = min(5, tax_amount // 200)
    user.reputation += rep_gain
    
    session.commit()
    
    query.edit_message_text(
        f"💰 You paid {format_coins(tax_amount)} in taxes to the kingdom!\n"
        f"➕ Gained {rep_gain} reputation\n\n"
        f"New reputation: {user.reputation}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def kingdom_back(update, context):
    """Go back to kingdom menu"""
    query = update.callback_query
    query.answer()
    kingdom(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("kingdom", kingdom))
    
    # Kingdom management callbacks
    dp.add_handler(CallbackQueryHandler(kingdom_manage, pattern='^kingdom_manage$'))
    dp.add_handler(CallbackQueryHandler(kingdom_treasury, pattern='^kingdom_treasury$'))
    dp.add_handler(CallbackQueryHandler(kingdom_withdraw, pattern='^kingdom_withdraw$'))
    dp.add_handler(CallbackQueryHandler(process_kingdom_withdrawal, pattern='^kingdom_withdraw_'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_custom_kingdom_withdrawal))
    dp.add_handler(CallbackQueryHandler(kingdom_change_tax, pattern='^kingdom_change_tax$'))
    dp.add_handler(CallbackQueryHandler(process_tax_change, pattern='^kingdom_settax_'))
    dp.add_handler(CallbackQueryHandler(kingdom_change_laws, pattern='^kingdom_change_laws$'))
    dp.add_handler(CallbackQueryHandler(set_theft_penalty, pattern='^kingdom_settheft$'))
    dp.add_handler(CallbackQueryHandler(process_theft_penalty, pattern='^kingdom_theft_'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_custom_theft_penalty))
    dp.add_handler(CallbackQueryHandler(set_murder_penalty, pattern='^kingdom_setmurder$'))
    dp.add_handler(CallbackQueryHandler(process_murder_penalty, pattern='^kingdom_murder_'))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, process_custom_murder_penalty))
    dp.add_handler(CallbackQueryHandler(kingdom_pay_taxes, pattern='^kingdom_taxes$'))
    
    # Navigation
    dp.add_handler(CallbackQueryHandler(kingdom_back, pattern='^kingdom_back$'))