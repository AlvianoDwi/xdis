from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, InventoryItem, Item, Transaction
from utils.helpers import format_coins, get_required_tool
from utils.decorators import log_command, requires_tool
import logging
import random

logger = logging.getLogger(__name__)

@log_command
def farming(update, context):
    """Show farming options"""
    keyboard = [
        [InlineKeyboardButton("Farm Crops", callback_data='farm_crops')],
        [InlineKeyboardButton("Tend Animals", callback_data='farm_animals')],
        [InlineKeyboardButton("Gather Herbs", callback_data='farm_herbs')],
        [InlineKeyboardButton("Check Tools", callback_data='farm_tools')],
    ]
    
    update.message.reply_text(
        "🌾 *Farming Menu* 🌾\n\n"
        "Work the land and tend to animals:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

@requires_tool('hoe')
def farm_crops(update, context):
    """Farm crops action"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Check energy
    energy_cost = 15
    if user.energy < energy_cost:
        query.edit_message_text(
            f"You need {energy_cost} energy to farm crops!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= energy_cost
    
    # Get farming tool
    tool = get_required_tool(user_id, 'hoe', session)
    if not tool:
        query.edit_message_text("You need a hoe to farm crops!")
        session.close()
        return
    
    # Reduce tool durability
    if tool.durability is not None:
        tool.durability -= 1
        if tool.durability <= 0:
            session.delete(tool)
            tool_broke = True
        else:
            tool_broke = False
    else:
        tool_broke = False
    
    # Possible crops
    crops = [
        {'id': 'wheat', 'name': 'Wheat', 'min': 1, 'max': 5, 'chance': 0.7},
        {'id': 'corn', 'name': 'Corn', 'min': 1, 'max': 3, 'chance': 0.5},
        {'id': 'carrot', 'name': 'Carrot', 'min': 1, 'max': 4, 'chance': 0.6},
        {'id': 'potato', 'name': 'Potato', 'min': 1, 'max': 6, 'chance': 0.4},
    ]
    
    # Calculate yield based on luck and tool quality
    luck_bonus = user.agility * 0.01
    quality_bonus = 1.0
    if hasattr(tool, 'item') and tool.item.stats and 'quality' in tool.item.stats:
        quality_bonus += tool.item.stats['quality'] * 0.1
    
    harvested = []
    for crop in crops:
        if random.random() < crop['chance'] * (1 + luck_bonus) * quality_bonus:
            amount = random.randint(crop['min'], crop['max'])
            harvested.append({'id': crop['id'], 'name': crop['name'], 'amount': amount})
            
            # Add to inventory
            existing = session.query(InventoryItem).filter(
                InventoryItem.user_id == user.id,
                InventoryItem.item_id == crop['id']
            ).first()
            
            if existing:
                existing.quantity += amount
            else:
                new_item = InventoryItem(
                    user_id=user.id,
                    item_id=crop['id'],
                    quantity=amount
                )
                session.add(new_item)
    
    # Calculate exp gain
    exp_gain = len(harvested) * 5
    user.exp += exp_gain
    
    # Format result message
    message = "🌾 *Farming Results* 🌾\n\n"
    if harvested:
        message += "You harvested:\n"
        for crop in harvested:
            message += f"• {crop['name']} x{crop['amount']}\n"
        
        message += f"\n⚔️ Gained {exp_gain} EXP\n"
    else:
        message += "Your harvest was unsuccessful this time.\n"
    
    if tool_broke:
        message += "\n⚠️ Your hoe broke from use!"
    
    # Check for level up
    current_level = user.level
    new_level = int(user.exp ** 0.5 / 10) + 1
    if new_level > current_level:
        user.level = new_level
        message += f"\n🎉 *Level Up!* You are now level {new_level}!"
    
    session.commit()
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

@requires_tool('fishing_rod')
def tend_animals(update, context):
    """Tend to animals action"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Check energy
    energy_cost = 20
    if user.energy < energy_cost:
        query.edit_message_text(
            f"You need {energy_cost} energy to tend animals!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= energy_cost
    
    # Get required tool
    tool = get_required_tool(user_id, 'fishing_rod', session)
    if not tool:
        query.edit_message_text("You need a fishing rod to tend animals!")
        session.close()
        return
    
    # Reduce tool durability
    if tool.durability is not None:
        tool.durability -= 1
        if tool.durability <= 0:
            session.delete(tool)
            tool_broke = True
        else:
            tool_broke = False
    else:
        tool_broke = False
    
    # Possible animal products
    products = [
        {'id': 'milk', 'name': 'Milk', 'min': 1, 'max': 3, 'chance': 0.6},
        {'id': 'eggs', 'name': 'Eggs', 'min': 1, 'max': 6, 'chance': 0.8},
        {'id': 'wool', 'name': 'Wool', 'min': 1, 'max': 2, 'chance': 0.4},
        {'id': 'meat', 'name': 'Meat', 'min': 1, 'max': 2, 'chance': 0.3},
    ]
    
    # Calculate yield based on luck and tool quality
    luck_bonus = user.agility * 0.01
    quality_bonus = 1.0
    if hasattr(tool, 'item') and tool.item.stats and 'quality' in tool.item.stats:
        quality_bonus += tool.item.stats['quality'] * 0.1
    
    gathered = []
    for product in products:
        if random.random() < product['chance'] * (1 + luck_bonus) * quality_bonus:
            amount = random.randint(product['min'], product['max'])
            gathered.append({'id': product['id'], 'name': product['name'], 'amount': amount})
            
            # Add to inventory
            existing = session.query(InventoryItem).filter(
                InventoryItem.user_id == user.id,
                InventoryItem.item_id == product['id']
            ).first()
            
            if existing:
                existing.quantity += amount
            else:
                new_item = InventoryItem(
                    user_id=user.id,
                    item_id=product['id'],
                    quantity=amount
                )
                session.add(new_item)
    
    # Calculate exp gain
    exp_gain = len(gathered) * 7
    user.exp += exp_gain
    
    # Format result message
    message = "🐄 *Animal Husbandry Results* 🐄\n\n"
    if gathered:
        message += "You gathered:\n"
        for product in gathered:
            message += f"• {product['name']} x{product['amount']}\n"
        
        message += f"\n⚔️ Gained {exp_gain} EXP\n"
    else:
        message += "The animals were not productive today.\n"
    
    if tool_broke:
        message += "\n⚠️ Your fishing rod broke from use!"
    
    # Check for level up
    current_level = user.level
    new_level = int(user.exp ** 0.5 / 10) + 1
    if new_level > current_level:
        user.level = new_level
        message += f"\n🎉 *Level Up!* You are now level {new_level}!"
    
    session.commit()
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

@requires_tool('sickle')
def gather_herbs(update, context):
    """Gather herbs action"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Check energy
    energy_cost = 12
    if user.energy < energy_cost:
        query.edit_message_text(
            f"You need {energy_cost} energy to gather herbs!\n"
            f"Current energy: {user.energy}/{user.max_energy}"
        )
        session.close()
        return
    
    # Deduct energy
    user.energy -= energy_cost
    
    # Get required tool
    tool = get_required_tool(user_id, 'sickle', session)
    if not tool:
        query.edit_message_text("You need a sickle to gather herbs!")
        session.close()
        return
    
    # Reduce tool durability
    if tool.durability is not None:
        tool.durability -= 1
        if tool.durability <= 0:
            session.delete(tool)
            tool_broke = True
        else:
            tool_broke = False
    else:
        tool_broke = False
    
    # Possible herbs
    herbs = [
        {'id': 'herb_common', 'name': 'Common Herb', 'min': 1, 'max': 5, 'chance': 0.8, 'rarity': 'common'},
        {'id': 'herb_rare', 'name': 'Rare Herb', 'min': 1, 'max': 2, 'chance': 0.3, 'rarity': 'uncommon'},
        {'id': 'herb_epic', 'name': 'Epic Herb', 'min': 1, 'max': 1, 'chance': 0.1, 'rarity': 'rare'},
        {'id': 'mushroom', 'name': 'Mushroom', 'min': 1, 'max': 3, 'chance': 0.5, 'rarity': 'common'},
    ]
    
    # Calculate yield based on luck and tool quality
    luck_bonus = user.intelligence * 0.02
    quality_bonus = 1.0
    if hasattr(tool, 'item') and tool.item.stats and 'quality' in tool.item.stats:
        quality_bonus += tool.item.stats['quality'] * 0.15
    
    gathered = []
    for herb in herbs:
        effective_chance = herb['chance'] * (1 + luck_bonus) * quality_bonus
        if random.random() < effective_chance:
            amount = random.randint(herb['min'], herb['max'])
            gathered.append({
                'id': herb['id'],
                'name': herb['name'],
                'amount': amount,
                'rarity': herb['rarity']
            })
            
            # Add to inventory
            existing = session.query(InventoryItem).filter(
                InventoryItem.user_id == user.id,
                InventoryItem.item_id == herb['id']
            ).first()
            
            if existing:
                existing.quantity += amount
            else:
                new_item = InventoryItem(
                    user_id=user.id,
                    item_id=herb['id'],
                    quantity=amount
                )
                session.add(new_item)
    
    # Calculate exp gain
    exp_gain = sum(h['amount'] * (1 + ['common', 'uncommon', 'rare'].index(h['rarity'])) for h in gathered)
    user.exp += exp_gain
    
    # Format result message
    message = "🌿 *Herb Gathering Results* 🌿\n\n"
    if gathered:
        message += "You gathered:\n"
        for herb in gathered:
            rarity_emoji = {
                'common': '',
                'uncommon': '🟢',
                'rare': '🔵'
            }.get(herb['rarity'], '')
            message += f"• {herb['name']} x{herb['amount']} {rarity_emoji}\n"
        
        message += f"\n⚔️ Gained {exp_gain} EXP\n"
    else:
        message += "You couldn't find any useful herbs this time.\n"
    
    if tool_broke:
        message += "\n⚠️ Your sickle broke from use!"
    
    # Check for level up
    current_level = user.level
    new_level = int(user.exp ** 0.5 / 10) + 1
    if new_level > current_level:
        user.level = new_level
        message += f"\n🎉 *Level Up!* You are now level {new_level}!"
    
    session.commit()
    query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    session.close()

def check_tools(update, context):
    """Check farming tools"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        query.edit_message_text("User not found!")
        session.close()
        return
    
    # Get all farming tools
    tools = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id,
        InventoryItem.item.has(type='tool'),
        InventoryItem.item.has(subtype.in_(['hoe', 'fishing_rod', 'sickle']))
    ).all()
    
    message = "🛠️ *Farming Tools* 🛠️\n\n"
    if tools:
        for tool in tools:
            durability_text = ""
            if tool.durability is not None:
                durability_text = f" ({tool.durability}/{tool.max_durability})"
            message += f"• {tool.item_id}{durability_text}\n"
    else:
        message += "You don't have any farming tools!\n"
        message += "Visit the market to buy some.\n"
    
    keyboard = [
        [InlineKeyboardButton("Back to Farming", callback_data='farm_back')],
        [InlineKeyboardButton("Visit Market", callback_data='farm_market')]
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def farming_back(update, context):
    """Go back to farming menu"""
    query = update.callback_query
    query.answer()
    farming(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("farm", farming))
    dp.add_handler(CallbackQueryHandler(farming, pattern='^farm_back$'))
    dp.add_handler(CallbackQueryHandler(farm_crops, pattern='^farm_crops$'))
    dp.add_handler(CallbackQueryHandler(tend_animals, pattern='^farm_animals$'))
    dp.add_handler(CallbackQueryHandler(gather_herbs, pattern='^farm_herbs$'))
    dp.add_handler(CallbackQueryHandler(check_tools, pattern='^farm_tools$'))