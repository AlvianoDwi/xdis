from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import CommandHandler, CallbackQueryHandler
from database.database import Session
from database.models import User, House, InventoryItem, Transaction
from utils.helpers import format_coins
from utils.decorators import log_command
import logging

logger = logging.getLogger(__name__)

@log_command
def housing(update, context):
    """Show housing options"""
    user_id = update.effective_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user:
        update.message.reply_text("User not found!")
        session.close()
        return
    
    # Get available houses
    houses = session.query(House).order_by(House.price).all()
    
    message = "🏠 *Housing Market* 🏠\n\n"
    
    if user.house:
        message += (
            f"Your current home: *{user.house.name}*\n"
            f"📦 Capacity: {user.house.capacity} inventory slots\n"
            f"⚡ Energy bonus: +{user.house.energy_bonus}\n\n"
            "Available upgrades:\n"
        )
    else:
        message += "You currently don't own a house.\n\nAvailable properties:\n"
    
    for house in houses:
        if user.house and user.house.id == house.id:
            continue  # Skip current house
        
        owned = ""
        if user.house and user.house.level_requirement > user.level:
            owned = f" (Requires Lv. {house.level_requirement})"
        
        message += (
            f"• *{house.name}* - {format_coins(house.price)}{owned}\n"
            f"  📦 Capacity: {house.capacity}  ⚡ Energy: +{house.energy_bonus}\n"
        )
    
    keyboard = []
    
    if user.house:
        keyboard.append(
            [InlineKeyboardButton("House Info", callback_data='house_info')]
        )
    
    for house in houses:
        if user.house and user.house.id == house.id:
            continue  # Skip current house
        
        if user.level >= house.level_requirement:
            keyboard.append(
                [InlineKeyboardButton(f"Buy {house.name}", callback_data=f'house_buy_{house.id}')]
            )
    
    update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def house_info(update, context):
    """Show current house information"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.house:
        query.edit_message_text("You don't own a house!")
        session.close()
        return
    
    house = user.house
    
    # Calculate inventory usage
    inventory_count = session.query(InventoryItem).filter(
        InventoryItem.user_id == user.id
    ).count()
    
    message = (
        f"🏠 *{house.name}* 🏠\n\n"
        f"📜 *Description:* {house.description}\n"
        f"📦 *Storage:* {inventory_count}/{house.capacity} items\n"
        f"⚡ *Energy Bonus:* +{house.energy_bonus}\n\n"
        "House benefits:\n"
        "• Increased inventory capacity\n"
        "• Bonus max energy\n"
        "• Resting restores more energy\n"
        "• Access to home crafting station\n"
    )
    
    keyboard = [
        [InlineKeyboardButton("Rest", callback_data='house_rest')],
        [InlineKeyboardButton("Upgrade House", callback_data='house_upgrade')],
        [InlineKeyboardButton("Back", callback_data='house_back')],
    ]
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def house_rest(update, context):
    """Rest at home to restore energy"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.house:
        query.edit_message_text("You don't own a house!")
        session.close()
        return
    
    # Check if already at full energy
    if user.energy >= user.max_energy:
        query.edit_message_text("You're already at full energy!")
        session.close()
        return
    
    # Calculate energy restore (based on house quality)
    energy_restore = min(30, user.max_energy - user.energy)
    energy_restore = max(10, energy_restore)  # At least 10
    
    # Apply energy restore
    user.energy += energy_restore
    
    session.commit()
    
    query.edit_message_text(
        f"💤 You rested at home and restored {energy_restore} energy!\n"
        f"Current energy: {user.energy}/{user.max_energy}",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def house_upgrade(update, context):
    """Show house upgrade options"""
    query = update.callback_query
    query.answer()
    
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.house:
        query.edit_message_text("You don't own a house!")
        session.close()
        return
    
    current_house = user.house
    
    # Get available upgrades
    upgrades = session.query(House).filter(
        House.price > current_house.price,
        House.level_requirement <= user.level
    ).order_by(House.price).all()
    
    if not upgrades:
        query.edit_message_text("No upgrades available for your current house!")
        session.close()
        return
    
    message = (
        f"🛠️ *Upgrade {current_house.name}* 🛠️\n\n"
        "Available upgrades:\n"
    )
    
    for house in upgrades:
        price_diff = house.price - current_house.price
        message += (
            f"• *{house.name}* - {format_coins(price_diff)}\n"
            f"  📦 Capacity: {house.capacity} (+{house.capacity - current_house.capacity})\n"
            f"  ⚡ Energy: +{house.energy_bonus} (+{house.energy_bonus - current_house.energy_bonus})\n"
        )
    
    keyboard = []
    for house in upgrades:
        keyboard.append(
            [InlineKeyboardButton(f"Upgrade to {house.name}", callback_data=f'house_upgradeto_{house.id}')]
        )
    
    keyboard.append([InlineKeyboardButton("Back", callback_data='house_info')])
    
    query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def process_house_upgrade(update, context):
    """Process house upgrade"""
    query = update.callback_query
    query.answer()
    
    house_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    
    if not user or not user.house:
        query.edit_message_text("You don't own a house!")
        session.close()
        return
    
    current_house = user.house
    new_house = session.query(House).get(house_id)
    
    if not new_house:
        query.edit_message_text("House not found!")
        session.close()
        return
    
    if new_house.price <= current_house.price:
        query.edit_message_text("This isn't an upgrade!")
        session.close()
        return
    
    if user.level < new_house.level_requirement:
        query.edit_message_text(
            f"You need level {new_house.level_requirement} to purchase this house!\n"
            f"Your level: {user.level}"
        )
        session.close()
        return
    
    upgrade_cost = new_house.price - current_house.price
    
    if user.coins < upgrade_cost:
        query.edit_message_text(
            f"You don't have enough coins for this upgrade!\n"
            f"Required: {format_coins(upgrade_cost)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Process upgrade
    user.coins -= upgrade_cost
    user.house_id = new_house.id
    
    # Adjust max energy
    energy_bonus_diff = new_house.energy_bonus - current_house.energy_bonus
    user.max_energy += energy_bonus_diff
    user.energy = min(user.energy, user.max_energy)  # Cap current energy
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=upgrade_cost,
        type="house_upgrade",
        details={
            "from_house": current_house.id,
            "to_house": new_house.id
        }
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"🏡 Congratulations! You've upgraded to {new_house.name}!\n\n"
        f"New benefits:\n"
        f"📦 Capacity: {new_house.capacity} (+{new_house.capacity - current_house.capacity})\n"
        f"⚡ Energy Bonus: +{new_house.energy_bonus} (+{energy_bonus_diff})\n",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def house_buy(update, context):
    """Process buying a house"""
    query = update.callback_query
    query.answer()
    
    house_id = int(query.data.split('_')[2])
    user_id = query.from_user.id
    session = Session()
    user = session.query(User).filter(User.telegram_id == user_id).first()
    house = session.query(House).get(house_id)
    
    if not user or not house:
        query.edit_message_text("User or house not found!")
        session.close()
        return
    
    if user.house:
        query.edit_message_text("You already own a house! Consider upgrading instead.")
        session.close()
        return
    
    if user.level < house.level_requirement:
        query.edit_message_text(
            f"You need level {house.level_requirement} to purchase this house!\n"
            f"Your level: {user.level}"
        )
        session.close()
        return
    
    if user.coins < house.price:
        query.edit_message_text(
            f"You don't have enough coins to buy this house!\n"
            f"Required: {format_coins(house.price)}\n"
            f"Your coins: {format_coins(user.coins)}"
        )
        session.close()
        return
    
    # Process purchase
    user.coins -= house.price
    user.house_id = house.id
    
    # Adjust max energy
    user.max_energy += house.energy_bonus
    user.energy = min(user.energy, user.max_energy)  # Cap current energy
    
    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        amount=house.price,
        type="house_purchase",
        details={"house_id": house.id}
    )
    session.add(transaction)
    session.commit()
    
    query.edit_message_text(
        f"🏡 Congratulations! You've purchased {house.name}!\n\n"
        f"House benefits:\n"
        f"📦 Capacity: {house.capacity} inventory slots\n"
        f"⚡ Energy Bonus: +{house.energy_bonus}\n\n"
        "Use /house to manage your new home.",
        parse_mode=ParseMode.MARKDOWN
    )
    session.close()

def house_back(update, context):
    """Go back to housing menu"""
    query = update.callback_query
    query.answer()
    housing(update, context)

def register_handlers(dp):
    dp.add_handler(CommandHandler("house", housing))
    dp.add_handler(CallbackQueryHandler(house_info, pattern='^house_info$'))
    dp.add_handler(CallbackQueryHandler(house_rest, pattern='^house_rest$'))
    dp.add_handler(CallbackQueryHandler(house_upgrade, pattern='^house_upgrade$'))
    dp.add_handler(CallbackQueryHandler(process_house_upgrade, pattern='^house_upgradeto_'))
    dp.add_handler(CallbackQueryHandler(house_buy, pattern='^house_buy_'))
    dp.add_handler(CallbackQueryHandler(house_back, pattern='^house_back$'))