import logging
from functools import wraps
from telegram import Update
from telegram.ext import CallbackContext
from database.database import Session
from database.models import User
from config.config import config

logger = logging.getLogger(__name__)

def restricted(admin_only=False):
    """Decorator to restrict access to certain users"""
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user_id = update.effective_user.id
            
            # Check if user is admin
            if admin_only and user_id not in config.ADMIN_IDS:
                logger.warning(f"Unauthorized admin access denied for {user_id}.")
                update.message.reply_text("This command is for admins only!")
                return
            
            # For non-admin restrictions, add additional checks here if needed
            
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator

def log_command(func):
    """Decorator to log command usage"""
    @wraps(func)
    def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
        user = update.effective_user
        command = update.message.text.split(' ')[0] if update.message else "Unknown"
        
        logger.info(
            f"Command '{command}' executed by "
            f"{user.username or user.first_name} (ID: {user.id})"
        )
        
        return func(update, context, *args, **kwargs)
    return wrapped

def cooldown(seconds=0, minutes=0, hours=0):
    """Decorator to add cooldown to commands"""
    total_seconds = seconds + minutes * 60 + hours * 3600
    
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user_id = update.effective_user.id
            session = Session()
            user = session.query(User).filter(User.telegram_id == user_id).first()
            
            if not user:
                update.message.reply_text("User not found!")
                session.close()
                return
            
            last_used = user.last_active
            now = datetime.utcnow()
            
            if last_used and (now - last_used).total_seconds() < total_seconds:
                remaining = total_seconds - (now - last_used).total_seconds()
                update.message.reply_text(
                    f"This command is on cooldown! "
                    f"Please wait {int(remaining)} seconds."
                )
                session.close()
                return
            
            # Update last active time
            user.last_active = now
            session.commit()
            session.close()
            
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator

def validate_input(*validators):
    """Decorator to validate command input"""
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            if not context.args:
                update.message.reply_text("This command requires arguments!")
                return
            
            for validator in validators:
                try:
                    validator(context.args)
                except ValueError as e:
                    update.message.reply_text(str(e))
                    return
            
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator

def anti_spam(func):
    """Decorator to prevent command spamming"""
    @wraps(func)
    def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
        user_id = update.effective_user.id
        now = datetime.utcnow()
        
        # Initialize user data if not exists
        if 'last_command_time' not in context.user_data:
            context.user_data['last_command_time'] = now
            return func(update, context, *args, **kwargs)
        
        last_time = context.user_data['last_command_time']
        elapsed = (now - last_time).total_seconds()
        
        if elapsed < 2:  # 2 seconds cooldown
            update.message.reply_text("Please wait a moment before using another command!")
            return
        
        context.user_data['last_command_time'] = now
        return func(update, context, *args, **kwargs)
    return wrapped

def check_resources(energy_cost=0, items=None):
    """Decorator to check if user has required resources"""
    if items is None:
        items = {}
    
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user_id = update.effective_user.id
            session = Session()
            user = session.query(User).filter(User.telegram_id == user_id).first()
            
            if not user:
                update.message.reply_text("User not found!")
                session.close()
                return
            
            # Check energy
            if energy_cost > 0 and user.energy < energy_cost:
                update.message.reply_text(
                    f"You need {energy_cost} energy to perform this action!\n"
                    f"Current energy: {user.energy}/{user.max_energy}"
                )
                session.close()
                return
            
            # Check items
            missing_items = []
            for item_id, quantity in items.items():
                inventory_item = session.query(InventoryItem).filter(
                    InventoryItem.user_id == user.id,
                    InventoryItem.item_id == item_id,
                    InventoryItem.quantity >= quantity
                ).first()
                
                if not inventory_item:
                    item = session.query(Item).get(item_id)
                    missing_items.append(f"{item.name} x{quantity}")
            
            if missing_items:
                update.message.reply_text(
                    "You're missing required items:\n" +
                    "\n".join(f"• {item}" for item in missing_items)
                )
                session.close()
                return
            
            session.close()
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator