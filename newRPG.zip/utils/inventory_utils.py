from database.database import Session
from database.models import InventoryItem

def add_item_to_inventory(user_id, item_id, quantity=1, durability=None):
    """Add item to user's inventory"""
    session = Session()
    
    try:
        # Check if item already exists in inventory
        existing_item = session.query(InventoryItem).filter(
            InventoryItem.user_id == user_id,
            InventoryItem.item_id == item_id,
            InventoryItem.durability == durability
        ).first()
        
        if existing_item:
            existing_item.quantity += quantity
        else:
            new_item = InventoryItem(
                user_id=user_id,
                item_id=item_id,
                quantity=quantity,
                durability=durability
            )
            session.add(new_item)
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def remove_item_from_inventory(user_id, item_id, quantity=1):
    """Remove item from user's inventory"""
    session = Session()
    
    try:
        item = session.query(InventoryItem).filter(
            InventoryItem.user_id == user_id,
            InventoryItem.item_id == item_id
        ).first()
        
        if not item or item.quantity < quantity:
            return False
        
        item.quantity -= quantity
        if item.quantity <= 0:
            session.delete(item)
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_inventory_count(user_id, item_id=None):
    """Get count of specific item or total items in inventory"""
    session = Session()
    
    try:
        if item_id:
            items = session.query(InventoryItem).filter(
                InventoryItem.user_id == user_id,
                InventoryItem.item_id == item_id
            ).all()
            return sum(item.quantity for item in items)
        else:
            return session.query(InventoryItem).filter(
                InventoryItem.user_id == user_id
            ).count()
    finally:
        session.close()