import logging
import os
from datetime import datetime
from config.config import config

def setup_logger():
    """Configure logging for the application"""
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    if config.DEBUG:
        logging.basicConfig(
            level=logging.DEBUG,
            format=log_format
        )
    else:
        # Create logs directory if not exists
        if not os.path.exists('logs'):
            os.makedirs('logs')
        
        log_file = f"logs/bot_{datetime.now().strftime('%Y%m%d')}.log"
        
        logging.basicConfig(
            level=logging.INFO,
            format=log_format,
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    
    # Silence some noisy logs
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('telegram').setLevel(logging.INFO)