def validate_username(username):
    """Validate username format"""
    if not username or len(username) > 32:
        raise ValueError("Username must be between 1-32 characters")
    return True

def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    return True

def validate_email(email):
    """Basic email validation"""
    if '@' not in email or '.' not in email:
        raise ValueError("Invalid email format")
    return True

def validate_item_id(item_id):
    """Validate item ID format"""
    if not item_id or len(item_id) > 50:
        raise ValueError("Invalid item ID")
    return True

def validate_positive_number(value, field_name="Value"):
    """Validate that value is a positive number"""
    try:
        num = float(value)
        if num <= 0:
            raise ValueError(f"{field_name} must be positive")
        return True
    except ValueError:
        raise ValueError(f"{field_name} must be a number")

def validate_integer(value, field_name="Value"):
    """Validate that value is an integer"""
    try:
        int(value)
        return True
    except ValueError:
        raise ValueError(f"{field_name} must be an integer")