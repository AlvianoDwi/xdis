from functools import wraps
from telegram import Update
from telegram.ext import CallbackContext
import logging
from datetime import datetime, timedelta
from database.database import Session
from database.models import User

logger = logging.getLogger(__name__)

def log_command(func):
    """Log command usage"""
    @wraps(func)
    def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
        user = update.effective_user
        command = update.message.text.split()[0] if update.message else "Unknown"
        
        logger.info(
            f"Command '{command}' executed by "
            f"{user.username or user.first_name} (ID: {user.id})"
        )
        return func(update, context, *args, **kwargs)
    return wrapped

def cooldown(seconds=0, minutes=0, hours=0):
    """Add cooldown to command"""
    total_seconds = seconds + minutes * 60 + hours * 3600
    
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user_id = update.effective_user.id
            session = Session()
            user = session.query(User).filter(User.telegram_id == user_id).first()
            
            if not user:
                update.message.reply_text("User not found!")
                session.close()
                return
            
            last_used = user.last_active
            now = datetime.utcnow()
            
            if last_used and (now - last_used).total_seconds() < total_seconds:
                remaining = total_seconds - (now - last_used).total_seconds()
                update.message.reply_text(
                    f"Please wait {int(remaining)} seconds before using this command again."
                )
                session.close()
                return
            
            user.last_active = now
            session.commit()
            session.close()
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator

def requires_item(item_id, quantity=1):
    """Check if user has required item"""
    def decorator(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user_id = update.effective_user.id
            session = Session()
            user = session.query(User).filter(User.telegram_id == user_id).first()
            
            if not user:
                update.message.reply_text("User not found!")
                session.close()
                return
            
            item = session.query(InventoryItem).filter(
                InventoryItem.user_id == user.id,
                InventoryItem.item_id == item_id,
                InventoryItem.quantity >= quantity
            ).first()
            
            if not item:
                update.message.reply_text(
                    f"You need {quantity}x {item_id} to use this command!"
                )
                session.close()
                return
            
            session.close()
            return func(update, context, *args, **kwargs)
        return wrapped
    return decorator