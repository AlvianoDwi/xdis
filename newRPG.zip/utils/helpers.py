from datetime import datetime
from math import floor
import random

def format_coins(amount):
    """Format coin amount with proper symbols"""
    if amount >= 1000000:
        return f"{amount/1000000:.1f}M💰"
    elif amount >= 1000:
        return f"{amount/1000:.1f}K💰"
    return f"{amount}💰"

def progress_bar(percentage, length=10):
    """Create a text progress bar"""
    filled = floor(percentage / 100 * length)
    empty = length - filled
    return f"[{'■' * filled}{'□' * empty}] {percentage:.1f}%"

def get_required_tool(user_id, tool_type, session):
    """Get user's tool of specified type with highest quality"""
    from database.models import InventoryItem, Item
    
    tools = session.query(InventoryItem).join(Item).filter(
        InventoryItem.user_id == user_id,
        Item.type == 'tool',
        Item.subtype == tool_type
    ).order_by(Item.stats['quality'].desc()).all()
    
    return tools[0] if tools else None

def calculate_durability_loss(item, action_intensity=1):
    """Calculate durability loss for an item"""
    base_loss = 1
    if hasattr(item, 'item') and item.item.stats and 'durability_loss' in item.item.stats:
        base_loss = item.item.stats['durability_loss']
    
    # Randomize loss a bit (±25%)
    randomized_loss = base_loss * random.uniform(0.75, 1.25)
    return max(1, int(randomized_loss * action_intensity))

def calculate_repair_cost(item):
    """Calculate repair cost for an item"""
    if not item.durability or not item.max_durability:
        return 0
    
    missing_durability = item.max_durability - item.durability
    value = item.item.value if hasattr(item, 'item') else 100
    return int(missing_durability * value * 0.1)  # 10% of item value per durability point

def random_weighted_choice(items):
    """Make a weighted random choice from a list of (item, weight) tuples"""
    total = sum(weight for item, weight in items)
    r = random.uniform(0, total)
    upto = 0
    for item, weight in items:
        if upto + weight >= r:
            return item
        upto += weight
    return items[-1][0]  # fallback to last item

def time_until_next_day():
    """Calculate time until next day (for daily rewards)"""
    now = datetime.utcnow()
    tomorrow = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
    return tomorrow - now

def format_time_delta(delta):
    """Format timedelta into human-readable string"""
    seconds = delta.total_seconds()
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    return f"{hours}h {minutes}m"

def calculate_level_exp(level):
    """Calculate total EXP needed for a level"""
    return 100 * (level ** 2)

def calculate_exp_gain(base_exp, user_level, target_level):
    """Calculate adjusted EXP gain based on level difference"""
    level_diff = target_level - user_level
    if level_diff >= 5:
        return base_exp * 2
    elif level_diff <= -5:
        return base_exp * 0.5
    return base_exp