from database.models import Item

TOOLS = [
    Item(
        id="wooden_hoe",
        name="Wooden Hoe",
        description="Basic farming tool",
        type="tool",
        subtype="hoe",
        rarity="common",
        value=50,
        stats={
            "quality": 1,
            "durability_loss": 1
        },
        durability=30,
        required_level=1,
        craftable=True,
        tradable=True
    ),
    Item(
        id="iron_hoe",
        name="Iron Hoe",
        description="Improved farming tool",
        type="tool",
        subtype="hoe",
        rarity="uncommon",
        value=120,
        stats={
            "quality": 2,
            "durability_loss": 1
        },
        durability=50,
        required_level=3,
        craftable=True,
        tradable=True
    ),
    Item(
        id="fishing_rod",
        name="Fishing Rod",
        description="Tool for catching fish",
        type="tool",
        subtype="fishing_rod",
        rarity="common",
        value=60,
        stats={
            "quality": 1,
            "durability_loss": 1
        },
        durability=25,
        required_level=1,
        craftable=True,
        tradable=True
    ),
    Item(
        id="sickle",
        name="Sickle",
        description="Tool for harvesting herbs",
        type="tool",
        subtype="sickle",
        rarity="common",
        value=55,
        stats={
            "quality": 1,
            "durability_loss": 1
        },
        durability=35,
        required_level=1,
        craftable=True,
        tradable=True
    )
]