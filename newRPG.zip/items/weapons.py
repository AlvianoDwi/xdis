from database.models import Item

WEAPONS = [
    Item(
        id="wooden_sword",
        name="Wooden Sword",
        description="A basic training sword made of wood",
        type="weapon",
        subtype="sword",
        rarity="common",
        value=50,
        stats={
            "attack": 5,
            "durability_loss": 1,
            "quality": 1
        },
        durability=30,
        required_level=1,
        craftable=True,
        tradable=True
    ),
    Item(
        id="iron_sword",
        name="Iron Sword",
        description="A standard iron sword",
        type="weapon",
        subtype="sword",
        rarity="uncommon",
        value=150,
        stats={
            "attack": 10,
            "durability_loss": 1,
            "quality": 2
        },
        durability=50,
        required_level=3,
        craftable=True,
        tradable=True
    ),
    Item(
        id="steel_sword",
        name="Steel Sword",
        description="A well-crafted steel sword",
        type="weapon",
        subtype="sword",
        rarity="rare",
        value=300,
        stats={
            "attack": 15,
            "durability_loss": 1,
            "quality": 3
        },
        durability=70,
        required_level=5,
        craftable=True,
        tradable=True
    ),
    Item(
        id="wooden_bow",
        name="Wooden Bow",
        description="A simple wooden bow",
        type="weapon",
        subtype="bow",
        rarity="common",
        value=60,
        stats={
            "attack": 6,
            "durability_loss": 1,
            "quality": 1
        },
        durability=25,
        required_level=1,
        craftable=True,
        tradable=True
    )
]