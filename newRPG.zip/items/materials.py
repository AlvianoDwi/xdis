from database.models import Item

MATERIALS = [
    Item(
        id="wood",
        name="Wood",
        description="Basic crafting material",
        type="material",
        subtype="wood",
        rarity="common",
        value=5,
        stats={},
        tradable=True
    ),
    Item(
        id="iron_ore",
        name="Iron Ore",
        description="Unrefined iron for crafting",
        type="material",
        subtype="ore",
        rarity="common",
        value=10,
        stats={},
        tradable=True
    ),
    Item(
        id="leather",
        name="Leather",
        description="Tanned animal hide",
        type="material",
        subtype="leather",
        rarity="common",
        value=8,
        stats={},
        tradable=True
    ),
    Item(
        id="herb",
        name="Herb",
        description="Medicinal plant for potions",
        type="material",
        subtype="herb",
        rarity="common",
        value=7,
        stats={},
        tradable=True
    )
]