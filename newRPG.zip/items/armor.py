from database.models import Item

ARMOR = [
    Item(
        id="leather_armor",
        name="Leather Armor",
        description="Basic armor made of tanned leather",
        type="armor",
        subtype="chest",
        rarity="common",
        value=80,
        stats={
            "defense": 5,
            "durability_loss": 1,
            "quality": 1
        },
        durability=40,
        required_level=1,
        craftable=True,
        tradable=True
    ),
    Item(
        id="iron_armor",
        name="Iron Armor",
        description="Standard iron plate armor",
        type="armor",
        subtype="chest",
        rarity="uncommon",
        value=200,
        stats={
            "defense": 10,
            "durability_loss": 1,
            "quality": 2
        },
        durability=60,
        required_level=3,
        craftable=True,
        tradable=True
    ),
    Item(
        id="steel_armor",
        name="Steel Armor",
        description="Well-crafted steel armor",
        type="armor",
        subtype="chest",
        rarity="rare",
        value=400,
        stats={
            "defense": 15,
            "durability_loss": 1,
            "quality": 3
        },
        durability=80,
        required_level=5,
        craftable=True,
        tradable=True
    ),
    Item(
        id="leather_helmet",
        name="Leather Helmet",
        description="Basic head protection",
        type="armor",
        subtype="head",
        rarity="common",
        value=40,
        stats={
            "defense": 3,
            "durability_loss": 1,
            "quality": 1
        },
        durability=30,
        required_level=1,
        craftable=True,
        tradable=True
    )
]