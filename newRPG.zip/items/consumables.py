from database.models import Item

CONSUMABLES = [
    Item(
        id="health_potion",
        name="Health Potion",
        description="Restores 20 health when consumed",
        type="consumable",
        subtype="potion",
        rarity="common",
        value=30,
        stats={},
        effect={
            "health_restore": 20
        },
        consumable=True,
        tradable=True
    ),
    Item(
        id="energy_potion",
        name="Energy Potion",
        description="Restores 15 energy when consumed",
        type="consumable",
        subtype="potion",
        rarity="common",
        value=25,
        stats={},
        effect={
            "energy_restore": 15
        },
        consumable=True,
        tradable=True
    ),
    Item(
        id="stamina_elixir",
        name="Stamina Elixir",
        description="Increases stamina by 5 for 1 hour",
        type="consumable",
        subtype="potion",
        rarity="uncommon",
        value=50,
        stats={},
        effect={
            "stamina_boost": 5,
            "duration": 60
        },
        consumable=True,
        tradable=True
    ),
    Item(
        id="bread",
        name="Bread",
        description="Basic food that restores 10 health and 5 energy",
        type="consumable",
        subtype="food",
        rarity="common",
        value=10,
        stats={},
        effect={
            "health_restore": 10,
            "energy_restore": 5
        },
        consumable=True,
        tradable=True
    )
]