from .armor import ARMOR_ITEMS
from .weapons import WEAPON_ITEMS
from .tools import TOOL_ITEMS
from .consumables import CONSUMABLE_ITEMS
from .materials import MATERIAL_ITEMS

ALL_ITEMS = {
    **ARMOR_ITEMS,
    **WEAPON_ITEMS,
    **TOOL_ITEMS,
    **CONSUMABLE_ITEMS,
    **MATERIAL_ITEMS
}

def get_item(item_id):
    """Get item data by ID"""
    return ALL_ITEMS.get(item_id)

def get_items_by_type(item_type):
    """Get all items of a specific type"""
    return {k: v for k, v in ALL_ITEMS.items() if v['type'] == item_type}